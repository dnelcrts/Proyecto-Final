Abrir en Eclipse: File > Import > Existing Projects into Workspace > seleccionar esta carpeta > Finish.
Clase principal: edu.dopo.App.
Para ejecutar sin Eclipse en Windows: doble clic en run.bat.
Para probar aceptación sin Eclipse en Windows: doble clic en run_acceptance.bat.
Las pruebas JUnit están en test/edu/dopo/domain.
