#!/bin/sh
mkdir -p bin
find src -name "*.java" > sources.tmp
javac -encoding UTF-8 -d bin @sources.tmp
rm sources.tmp
java -cp bin edu.dopo.App
