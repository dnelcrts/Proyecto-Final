@echo off
setlocal
if not exist bin mkdir bin
for /R src %%f in (*.java) do echo %%f>>sources.tmp
for /R test\edu\dopo\acceptance %%f in (*.java) do echo %%f>>sources.tmp
javac -encoding UTF-8 -d bin @sources.tmp
if errorlevel 1 (
  del sources.tmp
  pause
  exit /b 1
)
del sources.tmp
java -cp bin edu.dopo.acceptance.AcceptanceTest
pause
endlocal
