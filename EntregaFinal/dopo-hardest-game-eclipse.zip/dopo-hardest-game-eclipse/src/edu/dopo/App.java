package edu.dopo;

import java.io.File;

import javax.swing.SwingUtilities;

import edu.dopo.application.ErrorSink;
import edu.dopo.application.GameApplication;
import edu.dopo.application.GameUseCase;
import edu.dopo.application.LevelSource;
import edu.dopo.application.SaveStorage;
import edu.dopo.domain.factory.MachineCatalog;
import edu.dopo.domain.factory.SkinCatalog;
import edu.dopo.persistence.TextErrorSink;
import edu.dopo.persistence.TextLevelSource;
import edu.dopo.persistence.TextSaveStorage;
import edu.dopo.presentation.MainWindow;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    SkinCatalog skins = new SkinCatalog();
                    MachineCatalog machines = new MachineCatalog();
                    LevelSource levels = new TextLevelSource(new File("data/configs"), skins);
                    SaveStorage saves = new TextSaveStorage();
                    ErrorSink errors = new TextErrorSink(new File("data/errors.log"));
                    GameUseCase useCase = new GameApplication(levels, saves, skins, machines);
                    MainWindow window = new MainWindow(useCase, errors);
                    window.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
