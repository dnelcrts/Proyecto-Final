package edu.dopo.application;

public interface ErrorSink {
    void write(Exception exception);
}
