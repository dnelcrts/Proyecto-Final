package edu.dopo.application;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import edu.dopo.domain.ai.MachineStrategy;
import edu.dopo.domain.factory.MachineCatalog;
import edu.dopo.domain.factory.SkinCatalog;
import edu.dopo.domain.model.Coin;
import edu.dopo.domain.model.Enemy;
import edu.dopo.domain.model.Game;
import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.GameModes;
import edu.dopo.domain.model.GameObject;
import edu.dopo.domain.model.GameStatus;
import edu.dopo.domain.model.Level;
import edu.dopo.domain.model.Player;
import edu.dopo.domain.model.SpecialElement;
import edu.dopo.domain.model.Wall;
import edu.dopo.domain.model.Zone;
import edu.dopo.dto.GameSnapshot;
import edu.dopo.dto.PlayerStatus;
import edu.dopo.dto.RenderItem;
import edu.dopo.persistence.SaveState;

public class GameApplication implements GameUseCase {
    private LevelSource levelSource;
    private SaveStorage saveStorage;
    private SkinCatalog skinCatalog;
    private MachineCatalog machineCatalog;
    private Game game;
    private GameSetup setup;

    public GameApplication(LevelSource levelSource, SaveStorage saveStorage, SkinCatalog skinCatalog, MachineCatalog machineCatalog) {
        this.levelSource = levelSource;
        this.saveStorage = saveStorage;
        this.skinCatalog = skinCatalog;
        this.machineCatalog = machineCatalog;
    }

    public List<String> levelNames() throws GameException {
        return levelSource.names();
    }

    public List<String> skinNames() {
        return skinCatalog.keys();
    }

    public List<String> modeNames() {
        return Arrays.asList(GameModes.PLAYER, GameModes.PLAYER_VS_PLAYER, GameModes.PLAYER_VS_MACHINE);
    }

    public List<String> machineNames() {
        return machineCatalog.keys();
    }

    public void start(GameSetup setup) throws GameException {
        this.setup = setup;
        Level level = levelSource.load(setup.getLevelName());
        MachineStrategy machine = null;
        if (GameModes.PLAYER_VS_MACHINE.equals(setup.getMode())) {
            machine = machineCatalog.create(setup.getMachine());
        }
        game = new Game(level, setup.getMode(), skinCatalog.create(setup.getFirstSkin()), skinCatalog.create(setup.getSecondSkin()), setup.getFirstBorder(), setup.getSecondBorder(), machine);
    }

    public void tick(double seconds) throws GameException {
        if (game != null) {
            game.tick(seconds);
        }
    }

    public void setDirection(int playerNumber, double x, double y) throws GameException {
        if (game != null) {
            game.player(playerNumber).setDirection(x, y);
        }
    }

    public void pauseOrResume() {
        if (game == null) {
            return;
        }
        if (GameStatus.RUNNING.equals(game.getStatus())) {
            game.pause();
        } else if (GameStatus.PAUSED.equals(game.getStatus())) {
            game.resume();
        }
    }

    public void finish() {
        if (game != null) {
            game.finish();
        }
    }

    public void save(File file) throws GameException {
        if (game == null || setup == null) {
            throw new GameException("No hay partida activa");
        }
        SaveState state = new SaveState(setup.getLevelName(), setup.getMode(), setup.getFirstSkin(), setup.getSecondSkin(), setup.getFirstBorder(), setup.getSecondBorder(), setup.getMachine(), game.getRemainingTime());
        for (Coin coin : game.getLevel().getCoins()) {
            if (coin.isCollected()) {
                state.addCollectedCoin(coin.getId());
            }
        }
        for (SpecialElement element : game.getLevel().getSpecialElements()) {
            if (!element.isActive()) {
                state.addUsedElement(element.getId());
            }
        }
        for (Player player : game.getPlayers()) {
            String line = player.getNumber() + "," + player.getX() + "," + player.getY() + "," + player.getSpawn().getX() + "," + player.getSpawn().getY() + "," + player.getDeaths() + "," + player.getCollectedCoins() + "," + player.getLives();
            state.addPlayerLine(line);
        }
        saveStorage.save(file, state);
    }

    public void open(File file) throws GameException {
        SaveState state = saveStorage.load(file);
        GameSetup loadedSetup = new GameSetup(state.getLevelName(), state.getMode(), state.getFirstSkin(), state.getSecondSkin(), state.getFirstBorder(), state.getSecondBorder(), state.getMachine(), true);
        start(loadedSetup);
        game.setRemainingTime(state.getRemainingTime());
        for (Coin coin : game.getLevel().getCoins()) {
            if (state.getCollectedCoins().contains(coin.getId())) {
                coin.deactivate();
            }
        }
        for (SpecialElement element : game.getLevel().getSpecialElements()) {
            if (state.getUsedElements().contains(element.getId())) {
                element.deactivate();
            }
        }
        for (String playerLine : state.getPlayerLines()) {
            String[] parts = playerLine.split(",");
            Player player = game.player(Integer.parseInt(parts[0]));
            player.setPosition(Double.parseDouble(parts[1]), Double.parseDouble(parts[2]));
            player.setCheckpoint(Double.parseDouble(parts[3]), Double.parseDouble(parts[4]));
            player.setDeaths(Integer.parseInt(parts[5]));
            player.setCollectedCoins(Integer.parseInt(parts[6]));
            player.setLives(Integer.parseInt(parts[7]));
        }
    }

    public GameSnapshot snapshot() {
        if (game == null) {
            return new GameSnapshot("Sin partida", 760, 480, GameStatus.MENU, 0, 0);
        }
        Level level = game.getLevel();
        GameSnapshot snapshot = new GameSnapshot(level.getName(), level.getWidth(), level.getHeight(), game.getStatus(), game.getRemainingTime(), level.totalCoins());
        for (Zone zone : level.getZones()) {
            add(snapshot, zone, "", "");
        }
        for (Wall wall : level.getWalls()) {
            add(snapshot, wall, "", "");
        }
        for (Coin coin : level.getCoins()) {
            if (coin.isActive()) {
                add(snapshot, coin, "", "");
            }
        }
        for (SpecialElement element : level.getSpecialElements()) {
            if (element.isActive()) {
                add(snapshot, element, "", "");
            }
        }
        for (Enemy enemy : level.getEnemies()) {
            if (enemy.isActive()) {
                add(snapshot, enemy, "", "");
            }
        }
        for (Player player : game.getPlayers()) {
            add(snapshot, player, String.valueOf(player.getNumber()), player.getBorderName());
            snapshot.addPlayerStatus(new PlayerStatus(player.getNumber(), player.getDeaths(), player.getCollectedCoins(), player.getLives(), player.getSkinKey(), player.isCompleted()));
        }
        return snapshot;
    }

    private void add(GameSnapshot snapshot, GameObject object, String label, String border) {
        snapshot.addItem(new RenderItem(object.renderKey(), object.getX(), object.getY(), object.getWidth(), object.getHeight(), label, border));
    }
}
