package edu.dopo.application;

public class GameSetup {
    private String levelName;
    private String mode;
    private String firstSkin;
    private String secondSkin;
    private String firstBorder;
    private String secondBorder;
    private String machine;
    private boolean music;

    public GameSetup(String levelName, String mode, String firstSkin, String secondSkin, String firstBorder, String secondBorder, String machine, boolean music) {
        this.levelName = levelName;
        this.mode = mode;
        this.firstSkin = firstSkin;
        this.secondSkin = secondSkin;
        this.firstBorder = firstBorder;
        this.secondBorder = secondBorder;
        this.machine = machine;
        this.music = music;
    }

    public String getLevelName() {
        return levelName;
    }

    public String getMode() {
        return mode;
    }

    public String getFirstSkin() {
        return firstSkin;
    }

    public String getSecondSkin() {
        return secondSkin;
    }

    public String getFirstBorder() {
        return firstBorder;
    }

    public String getSecondBorder() {
        return secondBorder;
    }

    public String getMachine() {
        return machine;
    }

    public boolean hasMusic() {
        return music;
    }
}
