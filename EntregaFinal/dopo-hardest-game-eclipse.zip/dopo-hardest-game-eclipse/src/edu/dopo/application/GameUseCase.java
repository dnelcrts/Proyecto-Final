package edu.dopo.application;

import java.io.File;
import java.util.List;

import edu.dopo.domain.model.GameException;
import edu.dopo.dto.GameSnapshot;

public interface GameUseCase {
    List<String> levelNames() throws GameException;

    List<String> skinNames();

    List<String> modeNames();

    List<String> machineNames();

    void start(GameSetup setup) throws GameException;

    void tick(double seconds) throws GameException;

    void setDirection(int playerNumber, double x, double y) throws GameException;

    void pauseOrResume();

    void finish();

    void save(File file) throws GameException;

    void open(File file) throws GameException;

    GameSnapshot snapshot();
}
