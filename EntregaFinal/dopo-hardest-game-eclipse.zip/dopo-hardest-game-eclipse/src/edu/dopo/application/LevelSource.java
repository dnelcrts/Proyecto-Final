package edu.dopo.application;

import java.util.List;

import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.Level;

public interface LevelSource {
    List<String> names() throws GameException;

    Level load(String name) throws GameException;
}
