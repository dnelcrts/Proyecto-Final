package edu.dopo.application;

import java.io.File;

import edu.dopo.domain.model.GameException;
import edu.dopo.persistence.SaveState;

public interface SaveStorage {
    void save(File file, SaveState state) throws GameException;

    SaveState load(File file) throws GameException;
}
