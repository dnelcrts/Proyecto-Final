package edu.dopo.domain.ai;

import edu.dopo.domain.model.Coin;
import edu.dopo.domain.model.Game;
import edu.dopo.domain.model.Player;
import edu.dopo.domain.model.Vector2;
import edu.dopo.domain.model.Zone;
import edu.dopo.domain.model.ZoneKinds;

public class ExpertMachineStrategy implements MachineStrategy {
    public String key() {
        return "EXPERT";
    }

    public String name() {
        return "Experta";
    }

    public void decide(Game game, Player player, double seconds) {
        Vector2 target = nextTarget(game, player);
        Vector2 direction = new Vector2(target.getX() - player.getX(), target.getY() - player.getY()).normalized();
        player.setDirection(direction.getX(), direction.getY());
    }

    private Vector2 nextTarget(Game game, Player player) {
        Coin closest = null;
        double best = Double.MAX_VALUE;
        for (Coin coin : game.getLevel().getCoins()) {
            if (!coin.isCollected()) {
                double dx = coin.getX() - player.getX();
                double dy = coin.getY() - player.getY();
                double distance = dx * dx + dy * dy;
                if (distance < best) {
                    best = distance;
                    closest = coin;
                }
            }
        }
        if (closest != null) {
            return closest.getPosition();
        }
        try {
            Zone zone = game.getLevel().zoneFor(ZoneKinds.END, player.getNumber());
            return zone.getPosition();
        } catch (Exception e) {
            return player.getSpawn();
        }
    }
}
