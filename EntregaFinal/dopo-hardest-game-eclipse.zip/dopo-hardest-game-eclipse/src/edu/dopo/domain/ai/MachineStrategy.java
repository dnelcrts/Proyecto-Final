package edu.dopo.domain.ai;

import edu.dopo.domain.model.Game;
import edu.dopo.domain.model.Player;

public interface MachineStrategy {
    String key();

    String name();

    void decide(Game game, Player player, double seconds);
}
