package edu.dopo.domain.ai;

import java.util.Random;

import edu.dopo.domain.model.Game;
import edu.dopo.domain.model.Player;

public class RandomMachineStrategy implements MachineStrategy {
    private Random random;
    private double wait;

    public RandomMachineStrategy() {
        random = new Random();
        wait = 0;
    }

    public String key() {
        return "RANDOM";
    }

    public String name() {
        return "Aleatoria";
    }

    public void decide(Game game, Player player, double seconds) {
        wait -= seconds;
        if (wait <= 0) {
            int direction = random.nextInt(8);
            double x = 0;
            double y = 0;
            if (direction == 0) {
                y = -1;
            } else if (direction == 1) {
                y = 1;
            } else if (direction == 2) {
                x = -1;
            } else if (direction == 3) {
                x = 1;
            } else if (direction == 4) {
                x = -1;
                y = -1;
            } else if (direction == 5) {
                x = 1;
                y = -1;
            } else if (direction == 6) {
                x = -1;
                y = 1;
            } else {
                x = 1;
                y = 1;
            }
            player.setDirection(x, y);
            wait = 0.25 + random.nextDouble() * 0.5;
        }
    }
}
