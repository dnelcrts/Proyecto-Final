package edu.dopo.domain.factory;

import java.util.LinkedHashMap;
import java.util.Map;

import edu.dopo.domain.model.Coin;
import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.SkinCoin;
import edu.dopo.domain.model.YellowCoin;

public class CoinCatalog {
    private Map<String, CoinCreator> creators;
    private SkinCatalog skinCatalog;

    public CoinCatalog(SkinCatalog skinCatalog) {
        this.skinCatalog = skinCatalog;
        this.creators = new LinkedHashMap<String, CoinCreator>();
        creators.put("yellow", new CoinCreator() {
            public Coin create(String[] parts) {
                return new YellowCoin(parts[1], read(parts[2]), read(parts[3]));
            }
        });
        creators.put("skin", new CoinCreator() {
            public Coin create(String[] parts) {
                return new SkinCoin(parts[1], read(parts[2]), read(parts[3]), parts[4], CoinCatalog.this.skinCatalog);
            }
        });
    }

    public void register(String key, CoinCreator creator) {
        creators.put(key.toLowerCase(), creator);
    }

    public Coin create(String[] parts) throws GameException {
        CoinCreator creator = creators.get(parts[0].toLowerCase());
        if (creator == null) {
            throw new GameException("Moneda no encontrada: " + parts[0]);
        }
        return creator.create(parts);
    }

    private static double read(String value) {
        return Double.parseDouble(value.trim());
    }
}
