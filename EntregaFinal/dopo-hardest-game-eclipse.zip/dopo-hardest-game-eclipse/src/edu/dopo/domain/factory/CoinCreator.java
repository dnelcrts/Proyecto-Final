package edu.dopo.domain.factory;

import edu.dopo.domain.model.Coin;
import edu.dopo.domain.model.GameException;

public interface CoinCreator {
    Coin create(String[] parts) throws GameException;
}
