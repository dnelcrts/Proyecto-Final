package edu.dopo.domain.factory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import edu.dopo.domain.model.Enemy;
import edu.dopo.domain.model.FastEnemy;
import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.LinearEnemy;
import edu.dopo.domain.model.PatrolEnemy;
import edu.dopo.domain.model.Vector2;
import edu.dopo.domain.model.VerticalSliderEnemy;

public class EnemyCatalog {
    private Map<String, EnemyCreator> creators;

    public EnemyCatalog() {
        creators = new LinkedHashMap<String, EnemyCreator>();
        creators.put("linear", new EnemyCreator() {
            public Enemy create(String[] parts) {
                return new LinearEnemy(parts[1], read(parts[2]), read(parts[3]), read(parts[4]), read(parts[5]), read(parts[6]), read(parts[7]));
            }
        });
        creators.put("fast", new EnemyCreator() {
            public Enemy create(String[] parts) {
                return new FastEnemy(parts[1], read(parts[2]), read(parts[3]), read(parts[4]), read(parts[5]), read(parts[6]), read(parts[7]));
            }
        });
        creators.put("vertical", new EnemyCreator() {
            public Enemy create(String[] parts) {
                return new VerticalSliderEnemy(parts[1], read(parts[2]), read(parts[3]), read(parts[4]), read(parts[5]));
            }
        });
        creators.put("patrol", new EnemyCreator() {
            public Enemy create(String[] parts) {
                List<Vector2> points = new ArrayList<Vector2>();
                String[] rawPoints = parts[6].split("\\|");
                for (String rawPoint : rawPoints) {
                    String[] xy = rawPoint.split(":");
                    points.add(new Vector2(read(xy[0]), read(xy[1])));
                }
                return new PatrolEnemy(parts[1], read(parts[2]), read(parts[3]), read(parts[4]), read(parts[5]), points);
            }
        });
    }

    public void register(String key, EnemyCreator creator) {
        creators.put(key.toLowerCase(), creator);
    }

    public Enemy create(String[] parts) throws GameException {
        EnemyCreator creator = creators.get(parts[0].toLowerCase());
        if (creator == null) {
            throw new GameException("Enemigo no encontrado: " + parts[0]);
        }
        return creator.create(parts);
    }

    private static double read(String value) {
        return Double.parseDouble(value.trim());
    }
}
