package edu.dopo.domain.factory;

import edu.dopo.domain.model.Enemy;
import edu.dopo.domain.model.GameException;

public interface EnemyCreator {
    Enemy create(String[] parts) throws GameException;
}
