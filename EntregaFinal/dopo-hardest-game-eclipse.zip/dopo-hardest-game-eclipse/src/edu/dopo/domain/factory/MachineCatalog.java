package edu.dopo.domain.factory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import edu.dopo.domain.ai.ExpertMachineStrategy;
import edu.dopo.domain.ai.MachineStrategy;
import edu.dopo.domain.ai.RandomMachineStrategy;
import edu.dopo.domain.model.GameException;

public class MachineCatalog {
    private Map<String, MachineStrategyCreator> creators;

    public MachineCatalog() {
        creators = new LinkedHashMap<String, MachineStrategyCreator>();
        creators.put("RANDOM", new MachineStrategyCreator() {
            public MachineStrategy create() {
                return new RandomMachineStrategy();
            }
        });
        creators.put("EXPERT", new MachineStrategyCreator() {
            public MachineStrategy create() {
                return new ExpertMachineStrategy();
            }
        });
    }

    public void register(String key, MachineStrategyCreator creator) {
        creators.put(key.toUpperCase(), creator);
    }

    public MachineStrategy create(String key) throws GameException {
        MachineStrategyCreator creator = creators.get(key.toUpperCase());
        if (creator == null) {
            throw new GameException("Máquina no encontrada: " + key);
        }
        return creator.create();
    }

    public List<String> keys() {
        return new ArrayList<String>(creators.keySet());
    }
}
