package edu.dopo.domain.factory;

import edu.dopo.domain.ai.MachineStrategy;

public interface MachineStrategyCreator {
    MachineStrategy create();
}
