package edu.dopo.domain.factory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import edu.dopo.domain.model.GameException;
import edu.dopo.domain.skin.BlinkySkin;
import edu.dopo.domain.skin.ClydeSkin;
import edu.dopo.domain.skin.InkySkin;
import edu.dopo.domain.skin.PlayerSkin;

public class SkinCatalog {
    private Map<String, SkinCreator> creators;

    public SkinCatalog() {
        creators = new LinkedHashMap<String, SkinCreator>();
        creators.put("BLINKY", new SkinCreator() {
            public PlayerSkin create() {
                return new BlinkySkin();
            }
        });
        creators.put("INKY", new SkinCreator() {
            public PlayerSkin create() {
                return new InkySkin();
            }
        });
        creators.put("CLYDE", new SkinCreator() {
            public PlayerSkin create() {
                return new ClydeSkin();
            }
        });
    }

    public void register(String key, SkinCreator creator) {
        creators.put(key.toUpperCase(), creator);
    }

    public PlayerSkin create(String key) throws GameException {
        SkinCreator creator = creators.get(key.toUpperCase());
        if (creator == null) {
            throw new GameException("Skin no encontrada: " + key);
        }
        return creator.create();
    }

    public List<String> keys() {
        return new ArrayList<String>(creators.keySet());
    }
}
