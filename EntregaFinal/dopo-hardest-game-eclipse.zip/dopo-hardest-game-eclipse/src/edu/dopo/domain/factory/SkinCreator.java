package edu.dopo.domain.factory;

import edu.dopo.domain.skin.PlayerSkin;

public interface SkinCreator {
    PlayerSkin create();
}
