package edu.dopo.domain.factory;

import java.util.LinkedHashMap;
import java.util.Map;

import edu.dopo.domain.model.Bomb;
import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.LifeSource;
import edu.dopo.domain.model.SpecialElement;

public class SpecialCatalog {
    private Map<String, SpecialCreator> creators;

    public SpecialCatalog() {
        creators = new LinkedHashMap<String, SpecialCreator>();
        creators.put("life", new SpecialCreator() {
            public SpecialElement create(String[] parts) {
                return new LifeSource(parts[1], read(parts[2]), read(parts[3]));
            }
        });
        creators.put("bomb", new SpecialCreator() {
            public SpecialElement create(String[] parts) {
                return new Bomb(parts[1], read(parts[2]), read(parts[3]));
            }
        });
    }

    public void register(String key, SpecialCreator creator) {
        creators.put(key.toLowerCase(), creator);
    }

    public SpecialElement create(String[] parts) throws GameException {
        SpecialCreator creator = creators.get(parts[0].toLowerCase());
        if (creator == null) {
            throw new GameException("Elemento no encontrado: " + parts[0]);
        }
        return creator.create(parts);
    }

    private static double read(String value) {
        return Double.parseDouble(value.trim());
    }
}
