package edu.dopo.domain.factory;

import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.SpecialElement;

public interface SpecialCreator {
    SpecialElement create(String[] parts) throws GameException;
}
