package edu.dopo.domain.model;

public class Bomb extends SpecialElement {
    public Bomb(String id, double x, double y) {
        super(id, x, y, 24, 24);
    }

    public void affect(Player player) {
        if (isActive()) {
            player.forceDeath();
            deactivate();
        }
    }

    public boolean affectsEnemies() {
        return true;
    }

    public String renderKey() {
        return "BOMB";
    }
}
