package edu.dopo.domain.model;

public abstract class Coin extends GameObject {
    protected Coin(String id, double x, double y) {
        super(id, x, y, 18, 18);
    }

    public boolean isCollected() {
        return !isActive();
    }

    public void collect(Player player) throws GameException {
        if (isActive()) {
            applyTo(player);
            player.addCollectedCoin();
            deactivate();
        }
    }

    protected abstract void applyTo(Player player) throws GameException;
}
