package edu.dopo.domain.model;

public abstract class Enemy extends GameObject {
    protected Enemy(String id, double x, double y, double size) {
        super(id, x, y, size, size);
    }

    public abstract void move(Level level, double seconds);

    protected boolean touchesWallOrBorder(Level level, double nextX, double nextY) {
        Rect next = new Rect(nextX, nextY, getWidth(), getHeight());
        Rect board = new Rect(0, 0, level.getWidth(), level.getHeight());
        if (!board.contains(next)) {
            return true;
        }
        for (Wall wall : level.getWalls()) {
            if (next.intersects(wall.bounds())) {
                return true;
            }
        }
        return false;
    }
}
