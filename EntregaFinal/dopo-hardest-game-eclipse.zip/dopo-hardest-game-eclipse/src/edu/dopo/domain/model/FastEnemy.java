package edu.dopo.domain.model;

public class FastEnemy extends LinearEnemy {
    public FastEnemy(String id, double x, double y, double size, double directionX, double directionY, double speed) {
        super(id, x, y, size, directionX, directionY, speed * 2.0);
    }

    public String renderKey() {
        return "ENEMY_FAST";
    }
}
