package edu.dopo.domain.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import edu.dopo.domain.ai.MachineStrategy;
import edu.dopo.domain.service.CollisionService;
import edu.dopo.domain.service.MovementService;
import edu.dopo.domain.service.RuleEngine;
import edu.dopo.domain.skin.PlayerSkin;

public class Game {
    private Level level;
    private List<Player> players;
    private String mode;
    private String status;
    private double remainingTime;
    private MachineStrategy machineStrategy;
    private MovementService movementService;
    private RuleEngine ruleEngine;

    public Game(Level level, String mode, PlayerSkin firstSkin, PlayerSkin secondSkin, String firstBorder, String secondBorder, MachineStrategy machineStrategy) throws GameException {
        this.level = level;
        this.mode = mode;
        this.status = GameStatus.RUNNING;
        this.remainingTime = level.getTimeLimit();
        this.machineStrategy = machineStrategy;
        CollisionService collisionService = new CollisionService();
        this.movementService = new MovementService(collisionService);
        this.ruleEngine = new RuleEngine(collisionService);
        this.players = new ArrayList<Player>();
        createPlayers(firstSkin, secondSkin, firstBorder, secondBorder);
    }

    private void createPlayers(PlayerSkin firstSkin, PlayerSkin secondSkin, String firstBorder, String secondBorder) throws GameException {
        Zone start1 = level.zoneFor(ZoneKinds.START, 1);
        Player first = new Player(1, firstSkin, firstBorder, start1.getX(), start1.getY());
        first.setCheckpoint(start1.getX(), start1.getY());
        players.add(first);
        if (GameModes.PLAYER_VS_PLAYER.equals(mode) || GameModes.PLAYER_VS_MACHINE.equals(mode)) {
            Zone start2 = level.zoneFor(ZoneKinds.START, 2);
            Player second = new Player(2, secondSkin, secondBorder, start2.getX(), start2.getY());
            second.setCheckpoint(start2.getX(), start2.getY());
            players.add(second);
        }
    }

    public void tick(double seconds) throws GameException {
        if (!GameStatus.RUNNING.equals(status)) {
            return;
        }
        remainingTime -= seconds;
        if (remainingTime <= 0) {
            remainingTime = 0;
            status = GameStatus.LOST;
            return;
        }
        if (GameModes.PLAYER_VS_MACHINE.equals(mode) && players.size() > 1 && machineStrategy != null) {
            machineStrategy.decide(this, players.get(1), seconds);
        }
        for (Enemy enemy : level.getEnemies()) {
            enemy.move(level, seconds);
        }
        for (Player player : players) {
            movementService.move(player, level, seconds);
        }
        ruleEngine.apply(level, players);
        updateResult();
    }

    private void updateResult() {
        if (players.size() == 1) {
            if (players.get(0).isCompleted()) {
                status = GameStatus.WON;
            }
            return;
        }
        for (Player player : players) {
            if (player.isCompleted()) {
                status = GameStatus.WON;
            }
        }
    }

    public Level getLevel() {
        return level;
    }

    public List<Player> getPlayers() {
        return Collections.unmodifiableList(players);
    }

    public Player player(int number) throws GameException {
        for (Player player : players) {
            if (player.getNumber() == number) {
                return player;
            }
        }
        throw new GameException("Jugador no encontrado: " + number);
    }

    public String getMode() {
        return mode;
    }

    public String getStatus() {
        return status;
    }

    public double getRemainingTime() {
        return remainingTime;
    }

    public void setRemainingTime(double remainingTime) {
        this.remainingTime = remainingTime;
    }

    public void pause() {
        if (GameStatus.RUNNING.equals(status)) {
            status = GameStatus.PAUSED;
        }
    }

    public void resume() {
        if (GameStatus.PAUSED.equals(status)) {
            status = GameStatus.RUNNING;
        }
    }

    public void finish() {
        status = GameStatus.MENU;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
