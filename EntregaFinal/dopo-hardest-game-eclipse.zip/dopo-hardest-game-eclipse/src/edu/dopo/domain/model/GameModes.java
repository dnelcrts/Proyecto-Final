package edu.dopo.domain.model;

public final class GameModes {
    public static final String PLAYER = "PLAYER";
    public static final String PLAYER_VS_PLAYER = "PLAYER_VS_PLAYER";
    public static final String PLAYER_VS_MACHINE = "PLAYER_VS_MACHINE";

    private GameModes() {
    }
}
