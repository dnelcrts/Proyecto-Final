package edu.dopo.domain.model;

import java.io.Serializable;

public abstract class GameObject implements Serializable {
    private String id;
    private Vector2 position;
    private double width;
    private double height;
    private boolean active;

    protected GameObject(String id, double x, double y, double width, double height) {
        this.id = id;
        this.position = new Vector2(x, y);
        this.width = width;
        this.height = height;
        this.active = true;
    }

    public String getId() {
        return id;
    }

    public double getX() {
        return position.getX();
    }

    public double getY() {
        return position.getY();
    }

    public void setPosition(double x, double y) {
        position.set(x, y);
    }

    public Vector2 getPosition() {
        return position.copy();
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    protected void setSize(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public Rect bounds() {
        return new Rect(position.getX(), position.getY(), width, height);
    }

    public boolean isActive() {
        return active;
    }

    public void deactivate() {
        active = false;
    }

    public void activate() {
        active = true;
    }

    public abstract String renderKey();
}
