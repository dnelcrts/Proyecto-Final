package edu.dopo.domain.model;

public final class GameStatus {
    public static final String MENU = "MENU";
    public static final String RUNNING = "RUNNING";
    public static final String PAUSED = "PAUSED";
    public static final String WON = "WON";
    public static final String LOST = "LOST";

    private GameStatus() {
    }
}
