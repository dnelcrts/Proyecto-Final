package edu.dopo.domain.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Level implements Serializable {
    private String name;
    private int width;
    private int height;
    private int timeLimit;
    private List<Wall> walls;
    private List<Zone> zones;
    private List<Coin> coins;
    private List<Enemy> enemies;
    private List<SpecialElement> specialElements;

    public Level(String name, int width, int height, int timeLimit) {
        this.name = name;
        this.width = width;
        this.height = height;
        this.timeLimit = timeLimit;
        this.walls = new ArrayList<Wall>();
        this.zones = new ArrayList<Zone>();
        this.coins = new ArrayList<Coin>();
        this.enemies = new ArrayList<Enemy>();
        this.specialElements = new ArrayList<SpecialElement>();
    }

    public String getName() {
        return name;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getTimeLimit() {
        return timeLimit;
    }

    public void addWall(Wall wall) {
        walls.add(wall);
    }

    public void addZone(Zone zone) {
        zones.add(zone);
    }

    public void addCoin(Coin coin) {
        coins.add(coin);
    }

    public void addEnemy(Enemy enemy) {
        enemies.add(enemy);
    }

    public void addSpecialElement(SpecialElement element) {
        specialElements.add(element);
    }

    public List<Wall> getWalls() {
        return Collections.unmodifiableList(walls);
    }

    public List<Zone> getZones() {
        return Collections.unmodifiableList(zones);
    }

    public List<Coin> getCoins() {
        return Collections.unmodifiableList(coins);
    }

    public List<Enemy> getEnemies() {
        return Collections.unmodifiableList(enemies);
    }

    public List<SpecialElement> getSpecialElements() {
        return Collections.unmodifiableList(specialElements);
    }

    public int totalCoins() {
        return coins.size();
    }

    public boolean allCoinsCollected() {
        for (Coin coin : coins) {
            if (!coin.isCollected()) {
                return false;
            }
        }
        return true;
    }

    public Zone zoneFor(String kind, int playerNumber) throws GameException {
        for (Zone zone : zones) {
            if (zone.getKind().equals(kind) && zone.getPlayerNumber() == playerNumber) {
                return zone;
            }
        }
        for (Zone zone : zones) {
            if (zone.getKind().equals(kind) && zone.getPlayerNumber() == 1) {
                return zone;
            }
        }
        throw new GameException("Zona no encontrada: " + kind);
    }
}
