package edu.dopo.domain.model;

public class LifeSource extends SpecialElement {
    public LifeSource(String id, double x, double y) {
        super(id, x, y, 24, 24);
    }

    public void affect(Player player) {
        if (isActive()) {
            player.addLife();
            deactivate();
        }
    }

    public String renderKey() {
        return "LIFE";
    }
}
