package edu.dopo.domain.model;

public class LinearEnemy extends Enemy {
    private Vector2 direction;
    private double speed;

    public LinearEnemy(String id, double x, double y, double size, double directionX, double directionY, double speed) {
        super(id, x, y, size);
        this.direction = new Vector2(directionX, directionY).normalized();
        this.speed = speed;
    }

    public void move(Level level, double seconds) {
        if (!isActive()) {
            return;
        }
        double nextX = getX() + direction.getX() * speed * seconds;
        double nextY = getY() + direction.getY() * speed * seconds;
        if (touchesWallOrBorder(level, nextX, nextY)) {
            direction.set(-direction.getX(), -direction.getY());
            nextX = getX() + direction.getX() * speed * seconds;
            nextY = getY() + direction.getY() * speed * seconds;
            if (!touchesWallOrBorder(level, nextX, nextY)) {
                setPosition(nextX, nextY);
            }
        } else {
            setPosition(nextX, nextY);
        }
    }

    public String renderKey() {
        return "ENEMY_BASIC";
    }
}
