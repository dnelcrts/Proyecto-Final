package edu.dopo.domain.model;

import java.util.ArrayList;
import java.util.List;

public class PatrolEnemy extends Enemy {
    private List<Vector2> points;
    private int targetIndex;
    private double speed;

    public PatrolEnemy(String id, double x, double y, double size, double speed, List<Vector2> points) {
        super(id, x, y, size);
        this.points = new ArrayList<Vector2>(points);
        this.targetIndex = 0;
        this.speed = speed;
    }

    public void move(Level level, double seconds) {
        if (!isActive() || points.isEmpty()) {
            return;
        }
        Vector2 target = points.get(targetIndex);
        Vector2 delta = new Vector2(target.getX() - getX(), target.getY() - getY());
        double distance = delta.length();
        if (distance < 3) {
            targetIndex = (targetIndex + 1) % points.size();
            return;
        }
        Vector2 step = delta.normalized().times(speed * seconds);
        setPosition(getX() + step.getX(), getY() + step.getY());
    }

    public String renderKey() {
        return "ENEMY_PATROL";
    }
}
