package edu.dopo.domain.model;

import edu.dopo.domain.skin.PlayerSkin;

public class Player extends GameObject {
    private int number;
    private PlayerSkin originalSkin;
    private PlayerSkin currentSkin;
    private String borderName;
    private Vector2 spawn;
    private Vector2 direction;
    private int deaths;
    private int collectedCoins;
    private int lives;
    private boolean weakened;
    private boolean completed;

    public Player(int number, PlayerSkin skin, String borderName, double x, double y) {
        super("player" + number, x, y, 24.0 * skin.sizeFactor(), 24.0 * skin.sizeFactor());
        this.number = number;
        this.originalSkin = skin;
        this.currentSkin = skin;
        this.borderName = borderName;
        this.spawn = new Vector2(x, y);
        this.direction = new Vector2(0, 0);
        this.deaths = 0;
        this.collectedCoins = 0;
        this.lives = 0;
        this.weakened = false;
        this.completed = false;
    }

    public int getNumber() {
        return number;
    }

    public String getSkinKey() {
        return currentSkin.key();
    }

    public String getOriginalSkinKey() {
        return originalSkin.key();
    }

    public String getBorderName() {
        return borderName;
    }

    public void setDirection(double x, double y) {
        direction.set(x, y);
    }

    public Vector2 getDirection() {
        return direction.copy();
    }

    public double speed() {
        double base = 180.0;
        if (weakened) {
            return base * currentSkin.weakenedSpeedFactor();
        }
        return base * currentSkin.speedFactor();
    }

    public void changeSkin(PlayerSkin skin) {
        currentSkin = skin;
        weakened = false;
        setSize(24.0 * skin.sizeFactor(), 24.0 * skin.sizeFactor());
    }

    public void recoverOriginalSkin() {
        changeSkin(originalSkin);
    }

    public void setCheckpoint(double x, double y) {
        spawn.set(x, y);
    }

    public Vector2 getSpawn() {
        return spawn.copy();
    }

    public boolean hitByEnemy() {
        if (lives > 0) {
            lives--;
            return false;
        }
        if (currentSkin.absorbsFirstHit() && !weakened) {
            weakened = true;
            return false;
        }
        deaths++;
        recoverOriginalSkin();
        setPosition(spawn.getX(), spawn.getY());
        return true;
    }

    public void forceDeath() {
        deaths++;
        recoverOriginalSkin();
        setPosition(spawn.getX(), spawn.getY());
    }

    public int getDeaths() {
        return deaths;
    }

    public void setDeaths(int deaths) {
        this.deaths = deaths;
    }

    public void addCollectedCoin() {
        collectedCoins++;
    }

    public int getCollectedCoins() {
        return collectedCoins;
    }

    public void setCollectedCoins(int collectedCoins) {
        this.collectedCoins = collectedCoins;
    }

    public void addLife() {
        lives++;
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void complete() {
        completed = true;
    }

    public void resetCompletion() {
        completed = false;
    }

    public boolean isWeakened() {
        return weakened;
    }

    public String renderKey() {
        return currentSkin.renderKey();
    }
}
