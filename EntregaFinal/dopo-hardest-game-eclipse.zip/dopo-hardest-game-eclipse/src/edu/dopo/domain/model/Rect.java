package edu.dopo.domain.model;

import java.io.Serializable;

public class Rect implements Serializable {
    private double x;
    private double y;
    private double width;
    private double height;

    public Rect(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public double centerX() {
        return x + width / 2.0;
    }

    public double centerY() {
        return y + height / 2.0;
    }

    public boolean intersects(Rect other) {
        return x < other.x + other.width && x + width > other.x && y < other.y + other.height && y + height > other.y;
    }

    public boolean contains(Rect other) {
        return other.x >= x && other.y >= y && other.x + other.width <= x + width && other.y + other.height <= y + height;
    }

    public boolean containsPoint(double px, double py) {
        return px >= x && py >= y && px <= x + width && py <= y + height;
    }
}
