package edu.dopo.domain.model;

import edu.dopo.domain.factory.SkinCatalog;

public class SkinCoin extends Coin {
    private String skinKey;
    private SkinCatalog catalog;

    public SkinCoin(String id, double x, double y, String skinKey, SkinCatalog catalog) {
        super(id, x, y);
        this.skinKey = skinKey;
        this.catalog = catalog;
    }

    public String getSkinKey() {
        return skinKey;
    }

    protected void applyTo(Player player) throws GameException {
        player.changeSkin(catalog.create(skinKey));
    }

    public String renderKey() {
        return "COIN_SKIN_" + skinKey.toUpperCase();
    }
}
