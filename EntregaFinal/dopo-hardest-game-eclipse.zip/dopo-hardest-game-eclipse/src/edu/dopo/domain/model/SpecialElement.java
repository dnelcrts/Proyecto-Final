package edu.dopo.domain.model;

public abstract class SpecialElement extends GameObject {
    protected SpecialElement(String id, double x, double y, double width, double height) {
        super(id, x, y, width, height);
    }

    public abstract void affect(Player player);

    public boolean affectsEnemies() {
        return false;
    }
}
