package edu.dopo.domain.model;

public class VerticalSliderEnemy extends LinearEnemy {
    public VerticalSliderEnemy(String id, double x, double y, double size, double speed) {
        super(id, x, y, size, 0, 1, speed);
    }

    public String renderKey() {
        return "ENEMY_VERTICAL";
    }
}
