package edu.dopo.domain.model;

public class Wall extends GameObject {
    public Wall(String id, double x, double y, double width, double height) {
        super(id, x, y, width, height);
    }

    public String renderKey() {
        return "WALL";
    }
}
