package edu.dopo.domain.model;

public class YellowCoin extends Coin {
    public YellowCoin(String id, double x, double y) {
        super(id, x, y);
    }

    protected void applyTo(Player player) {
    }

    public String renderKey() {
        return "COIN_YELLOW";
    }
}
