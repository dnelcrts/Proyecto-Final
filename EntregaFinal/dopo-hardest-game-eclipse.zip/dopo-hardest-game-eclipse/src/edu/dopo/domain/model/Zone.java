package edu.dopo.domain.model;

public class Zone extends GameObject {
    private String kind;
    private int playerNumber;

    public Zone(String id, String kind, int playerNumber, double x, double y, double width, double height) {
        super(id, x, y, width, height);
        this.kind = kind;
        this.playerNumber = playerNumber;
    }

    public String getKind() {
        return kind;
    }

    public int getPlayerNumber() {
        return playerNumber;
    }

    public String renderKey() {
        if (ZoneKinds.END.equals(kind)) {
            return "ZONE_END";
        }
        if (ZoneKinds.MIDDLE.equals(kind)) {
            return "ZONE_MIDDLE";
        }
        return "ZONE_START";
    }
}
