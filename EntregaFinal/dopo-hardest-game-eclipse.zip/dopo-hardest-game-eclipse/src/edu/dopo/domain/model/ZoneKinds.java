package edu.dopo.domain.model;

public final class ZoneKinds {
    public static final String START = "START";
    public static final String MIDDLE = "MIDDLE";
    public static final String END = "END";

    private ZoneKinds() {
    }
}
