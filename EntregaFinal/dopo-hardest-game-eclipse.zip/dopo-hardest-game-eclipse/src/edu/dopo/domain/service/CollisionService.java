package edu.dopo.domain.service;

import edu.dopo.domain.model.GameObject;
import edu.dopo.domain.model.Level;
import edu.dopo.domain.model.Player;
import edu.dopo.domain.model.Rect;
import edu.dopo.domain.model.Wall;

public class CollisionService {
    public boolean intersects(GameObject first, GameObject second) {
        return first.isActive() && second.isActive() && first.bounds().intersects(second.bounds());
    }

    public boolean canOccupy(Level level, Rect bounds) {
        Rect board = new Rect(0, 0, level.getWidth(), level.getHeight());
        if (!board.contains(bounds)) {
            return false;
        }
        for (Wall wall : level.getWalls()) {
            if (bounds.intersects(wall.bounds())) {
                return false;
            }
        }
        return true;
    }

    public boolean playersCollide(Player first, Player second) {
        return first.bounds().intersects(second.bounds());
    }
}
