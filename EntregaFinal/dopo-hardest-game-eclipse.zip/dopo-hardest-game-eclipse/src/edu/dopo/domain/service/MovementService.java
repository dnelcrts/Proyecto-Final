package edu.dopo.domain.service;

import edu.dopo.domain.model.Level;
import edu.dopo.domain.model.Player;
import edu.dopo.domain.model.Rect;
import edu.dopo.domain.model.Vector2;

public class MovementService {
    private CollisionService collisionService;

    public MovementService(CollisionService collisionService) {
        this.collisionService = collisionService;
    }

    public void move(Player player, Level level, double seconds) {
        Vector2 direction = player.getDirection();
        if (direction.length() == 0) {
            return;
        }
        Vector2 step = direction.normalized().times(player.speed() * seconds);
        double nextX = player.getX() + step.getX();
        double nextY = player.getY() + step.getY();
        Rect nextBounds = new Rect(nextX, nextY, player.getWidth(), player.getHeight());
        if (collisionService.canOccupy(level, nextBounds)) {
            player.setPosition(nextX, nextY);
            return;
        }
        Rect horizontal = new Rect(nextX, player.getY(), player.getWidth(), player.getHeight());
        if (collisionService.canOccupy(level, horizontal)) {
            player.setPosition(nextX, player.getY());
        }
        Rect vertical = new Rect(player.getX(), nextY, player.getWidth(), player.getHeight());
        if (collisionService.canOccupy(level, vertical)) {
            player.setPosition(player.getX(), nextY);
        }
    }
}
