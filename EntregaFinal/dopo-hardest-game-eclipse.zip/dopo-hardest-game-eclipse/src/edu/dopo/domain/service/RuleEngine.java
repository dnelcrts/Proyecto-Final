package edu.dopo.domain.service;

import java.util.List;

import edu.dopo.domain.model.Coin;
import edu.dopo.domain.model.Enemy;
import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.Level;
import edu.dopo.domain.model.Player;
import edu.dopo.domain.model.SpecialElement;
import edu.dopo.domain.model.Zone;
import edu.dopo.domain.model.ZoneKinds;

public class RuleEngine {
    private CollisionService collisionService;

    public RuleEngine(CollisionService collisionService) {
        this.collisionService = collisionService;
    }

    public void apply(Level level, List<Player> players) throws GameException {
        applyPlayerObjects(level, players);
        applyEnemies(level, players);
        applyPlayerCollisions(players);
        applyZones(level, players);
    }

    private void applyPlayerObjects(Level level, List<Player> players) throws GameException {
        for (Player player : players) {
            for (Coin coin : level.getCoins()) {
                if (collisionService.intersects(player, coin)) {
                    coin.collect(player);
                }
            }
            for (SpecialElement element : level.getSpecialElements()) {
                if (collisionService.intersects(player, element)) {
                    element.affect(player);
                }
            }
        }
    }

    private void applyEnemies(Level level, List<Player> players) {
        for (Enemy enemy : level.getEnemies()) {
            for (Player player : players) {
                if (enemy.isActive() && collisionService.intersects(player, enemy)) {
                    player.hitByEnemy();
                }
            }
            for (SpecialElement element : level.getSpecialElements()) {
                if (element.affectsEnemies() && collisionService.intersects(enemy, element)) {
                    enemy.deactivate();
                    element.deactivate();
                }
            }
        }
    }

    private void applyPlayerCollisions(List<Player> players) {
        if (players.size() < 2) {
            return;
        }
        Player first = players.get(0);
        Player second = players.get(1);
        if (collisionService.playersCollide(first, second)) {
            first.forceDeath();
            second.forceDeath();
        }
    }

    private void applyZones(Level level, List<Player> players) {
        for (Player player : players) {
            for (Zone zone : level.getZones()) {
                if (zone.getPlayerNumber() == player.getNumber() && player.bounds().intersects(zone.bounds())) {
                    if (ZoneKinds.MIDDLE.equals(zone.getKind())) {
                        player.setCheckpoint(zone.getX(), zone.getY());
                    }
                    if (ZoneKinds.END.equals(zone.getKind()) && level.allCoinsCollected()) {
                        player.complete();
                    }
                }
            }
        }
    }
}
