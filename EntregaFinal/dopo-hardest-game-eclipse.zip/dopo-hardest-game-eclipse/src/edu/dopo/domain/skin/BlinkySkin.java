package edu.dopo.domain.skin;

public class BlinkySkin extends PlayerSkin {
    public String key() {
        return "BLINKY";
    }

    public String name() {
        return "Rojo Blinky";
    }

    public double speedFactor() {
        return 1.0;
    }

    public double sizeFactor() {
        return 1.0;
    }

    public boolean absorbsFirstHit() {
        return false;
    }

    public double weakenedSpeedFactor() {
        return 1.0;
    }

    public String renderKey() {
        return "PLAYER_BLINKY";
    }
}
