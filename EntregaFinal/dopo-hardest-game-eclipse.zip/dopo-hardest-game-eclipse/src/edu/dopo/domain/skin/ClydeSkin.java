package edu.dopo.domain.skin;

public class ClydeSkin extends PlayerSkin {
    public String key() {
        return "CLYDE";
    }

    public String name() {
        return "Verde Clyde";
    }

    public double speedFactor() {
        return 1.0;
    }

    public double sizeFactor() {
        return 1.0;
    }

    public boolean absorbsFirstHit() {
        return true;
    }

    public double weakenedSpeedFactor() {
        return 0.7;
    }

    public String renderKey() {
        return "PLAYER_CLYDE";
    }
}
