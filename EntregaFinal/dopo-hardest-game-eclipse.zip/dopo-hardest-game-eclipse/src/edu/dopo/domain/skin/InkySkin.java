package edu.dopo.domain.skin;

public class InkySkin extends PlayerSkin {
    public String key() {
        return "INKY";
    }

    public String name() {
        return "Azul Inky";
    }

    public double speedFactor() {
        return 1.5;
    }

    public double sizeFactor() {
        return 1.5;
    }

    public boolean absorbsFirstHit() {
        return false;
    }

    public double weakenedSpeedFactor() {
        return 1.5;
    }

    public String renderKey() {
        return "PLAYER_INKY";
    }
}
