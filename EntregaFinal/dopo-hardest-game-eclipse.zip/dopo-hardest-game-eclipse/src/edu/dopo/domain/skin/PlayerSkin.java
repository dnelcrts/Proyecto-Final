package edu.dopo.domain.skin;

import java.io.Serializable;

public abstract class PlayerSkin implements Serializable {
    public abstract String key();

    public abstract String name();

    public abstract double speedFactor();

    public abstract double sizeFactor();

    public abstract boolean absorbsFirstHit();

    public abstract double weakenedSpeedFactor();

    public abstract String renderKey();
}
