package edu.dopo.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GameSnapshot {
    private String levelName;
    private int width;
    private int height;
    private String status;
    private double remainingTime;
    private int totalCoins;
    private List<RenderItem> renderItems;
    private List<PlayerStatus> playerStatus;

    public GameSnapshot(String levelName, int width, int height, String status, double remainingTime, int totalCoins) {
        this.levelName = levelName;
        this.width = width;
        this.height = height;
        this.status = status;
        this.remainingTime = remainingTime;
        this.totalCoins = totalCoins;
        this.renderItems = new ArrayList<RenderItem>();
        this.playerStatus = new ArrayList<PlayerStatus>();
    }

    public String getLevelName() {
        return levelName;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public String getStatus() {
        return status;
    }

    public double getRemainingTime() {
        return remainingTime;
    }

    public int getTotalCoins() {
        return totalCoins;
    }

    public void addItem(RenderItem item) {
        renderItems.add(item);
    }

    public void addPlayerStatus(PlayerStatus status) {
        playerStatus.add(status);
    }

    public List<RenderItem> getRenderItems() {
        return Collections.unmodifiableList(renderItems);
    }

    public List<PlayerStatus> getPlayerStatus() {
        return Collections.unmodifiableList(playerStatus);
    }
}
