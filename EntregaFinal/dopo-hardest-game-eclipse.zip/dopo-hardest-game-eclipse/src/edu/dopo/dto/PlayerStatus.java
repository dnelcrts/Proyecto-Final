package edu.dopo.dto;

public class PlayerStatus {
    private int number;
    private int deaths;
    private int coins;
    private int lives;
    private String skin;
    private boolean completed;

    public PlayerStatus(int number, int deaths, int coins, int lives, String skin, boolean completed) {
        this.number = number;
        this.deaths = deaths;
        this.coins = coins;
        this.lives = lives;
        this.skin = skin;
        this.completed = completed;
    }

    public int getNumber() {
        return number;
    }

    public int getDeaths() {
        return deaths;
    }

    public int getCoins() {
        return coins;
    }

    public int getLives() {
        return lives;
    }

    public String getSkin() {
        return skin;
    }

    public boolean isCompleted() {
        return completed;
    }
}
