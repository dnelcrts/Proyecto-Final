package edu.dopo.dto;

public class RenderItem {
    private String key;
    private double x;
    private double y;
    private double width;
    private double height;
    private String label;
    private String border;

    public RenderItem(String key, double x, double y, double width, double height, String label, String border) {
        this.key = key;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.label = label;
        this.border = border;
    }

    public String getKey() {
        return key;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public String getLabel() {
        return label;
    }

    public String getBorder() {
        return border;
    }
}
