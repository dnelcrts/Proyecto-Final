package edu.dopo.persistence;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SaveState {
    private String levelName;
    private String mode;
    private String firstSkin;
    private String secondSkin;
    private String firstBorder;
    private String secondBorder;
    private String machine;
    private double remainingTime;
    private List<String> collectedCoins;
    private List<String> usedElements;
    private List<String> playerLines;

    public SaveState(String levelName, String mode, String firstSkin, String secondSkin, String firstBorder, String secondBorder, String machine, double remainingTime) {
        this.levelName = levelName;
        this.mode = mode;
        this.firstSkin = firstSkin;
        this.secondSkin = secondSkin;
        this.firstBorder = firstBorder;
        this.secondBorder = secondBorder;
        this.machine = machine;
        this.remainingTime = remainingTime;
        this.collectedCoins = new ArrayList<String>();
        this.usedElements = new ArrayList<String>();
        this.playerLines = new ArrayList<String>();
    }

    public String getLevelName() {
        return levelName;
    }

    public String getMode() {
        return mode;
    }

    public String getFirstSkin() {
        return firstSkin;
    }

    public String getSecondSkin() {
        return secondSkin;
    }

    public String getFirstBorder() {
        return firstBorder;
    }

    public String getSecondBorder() {
        return secondBorder;
    }

    public String getMachine() {
        return machine;
    }

    public double getRemainingTime() {
        return remainingTime;
    }

    public void addCollectedCoin(String id) {
        collectedCoins.add(id);
    }

    public void addUsedElement(String id) {
        usedElements.add(id);
    }

    public void addPlayerLine(String line) {
        playerLines.add(line);
    }

    public List<String> getCollectedCoins() {
        return Collections.unmodifiableList(collectedCoins);
    }

    public List<String> getUsedElements() {
        return Collections.unmodifiableList(usedElements);
    }

    public List<String> getPlayerLines() {
        return Collections.unmodifiableList(playerLines);
    }
}
