package edu.dopo.persistence;

import java.io.File;

import java.nio.file.Files;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import edu.dopo.application.ErrorSink;

public class TextErrorSink implements ErrorSink {
    private File file;

    public TextErrorSink(File file) {
        this.file = file;
    }

    public void write(Exception exception) {
        try {
            File parent = file.getParentFile();
            if (parent != null) {
                parent.mkdirs();
            }
            PrintWriter writer = new PrintWriter(Files.newBufferedWriter(file.toPath(), 
            	    java.nio.file.StandardOpenOption.CREATE, 
            	    java.nio.file.StandardOpenOption.APPEND));
            writer.println(LocalDateTime.now() + " " + exception.getClass().getName() + " " + exception.getMessage());
            for (StackTraceElement element : exception.getStackTrace()) {
                writer.println(element.toString());
            }
            writer.close();
        } catch (Exception e) {
        }
    }
}
