package edu.dopo.persistence;

import java.io.BufferedReader;

import java.nio.file.Files;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

import edu.dopo.application.LevelSource;
import edu.dopo.domain.factory.CoinCatalog;
import edu.dopo.domain.factory.EnemyCatalog;
import edu.dopo.domain.factory.SkinCatalog;
import edu.dopo.domain.factory.SpecialCatalog;
import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.Level;
import edu.dopo.domain.model.Wall;
import edu.dopo.domain.model.Zone;
import edu.dopo.domain.model.ZoneKinds;

public class TextLevelSource implements LevelSource {
    private File directory;
    private CoinCatalog coinCatalog;
    private EnemyCatalog enemyCatalog;
    private SpecialCatalog specialCatalog;

    public TextLevelSource(File directory, SkinCatalog skinCatalog) {
        this.directory = directory;
        this.coinCatalog = new CoinCatalog(skinCatalog);
        this.enemyCatalog = new EnemyCatalog();
        this.specialCatalog = new SpecialCatalog();
    }

    public List<String> names() throws GameException {
        TreeMap<String, String> names = new TreeMap<String, String>();
        File[] files = directory.listFiles();
        if (files == null) {
            throw new GameException("No se pudo leer la carpeta de configuraciones");
        }
        for (File file : files) {
            if (file.getName().endsWith(".txt")) {
                String name = readName(file);
                names.put(name, name);
            }
        }
        return new ArrayList<String>(names.values());
    }

    public Level load(String name) throws GameException {
        File selected = null;
        File[] files = directory.listFiles();
        if (files == null) {
            throw new GameException("No se pudo leer la carpeta de configuraciones");
        }
        for (File file : files) {
            if (file.getName().endsWith(".txt") && readName(file).equals(name)) {
                selected = file;
            }
        }
        if (selected == null) {
            throw new GameException("Configuración no encontrada: " + name);
        }
        return readLevel(selected);
    }

    private String readName(File file) throws GameException {
        try {
        	BufferedReader reader = Files.newBufferedReader(file.toPath());
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("name=")) {
                    reader.close();
                    return line.substring(5).trim();
                }
            }
            reader.close();
            return file.getName();
        } catch (IOException e) {
            throw new GameException("No se pudo leer el nombre del nivel", e);
        }
    }

    private Level readLevel(File file) throws GameException {
        try {
            List<String> lines = readLines(file);
            String name = value(lines, "name", file.getName());
            int width = integer(value(lines, "width", "760"));
            int height = integer(value(lines, "height", "480"));
            int time = integer(value(lines, "time", "90"));
            Level level = new Level(name, width, height, time);
            for (String line : lines) {
                if (line.startsWith("zone=")) {
                    addZone(level, data(line));
                } else if (line.startsWith("wall=")) {
                    addWall(level, data(line));
                } else if (line.startsWith("coin=")) {
                    level.addCoin(coinCatalog.create(data(line)));
                } else if (line.startsWith("enemy=")) {
                    level.addEnemy(enemyCatalog.create(data(line)));
                } else if (line.startsWith("special=")) {
                    level.addSpecialElement(specialCatalog.create(data(line)));
                }
            }
            return level;
        } catch (IOException e) {
            throw new GameException("No se pudo leer la configuración", e);
        }
    }

    private List<String> readLines(File file) throws IOException {
        List<String> lines = new ArrayList<String>();
        BufferedReader reader = Files.newBufferedReader(file.toPath());
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.length() > 0) {
                lines.add(line);
            }
        }
        reader.close();
        return lines;
    }

    private String value(List<String> lines, String key, String defaultValue) {
        for (String line : lines) {
            if (line.startsWith(key + "=")) {
                return line.substring(key.length() + 1).trim();
            }
        }
        return defaultValue;
    }

    private String[] data(String line) {
        String value = line.substring(line.indexOf('=') + 1);
        String[] parts = value.split(",");
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim();
        }
        return parts;
    }

    private void addZone(Level level, String[] parts) {
        String kind = parts[0].toUpperCase();
        int player = integer(parts[1]);
        level.addZone(new Zone("zone" + kind + player + level.getZones().size(), kind, player, read(parts[2]), read(parts[3]), read(parts[4]), read(parts[5])));
    }

    private void addWall(Level level, String[] parts) {
        level.addWall(new Wall(parts[0], read(parts[1]), read(parts[2]), read(parts[3]), read(parts[4])));
    }

    private int integer(String value) {
        return Integer.parseInt(value.trim());
    }

    private double read(String value) {
        return Double.parseDouble(value.trim());
    }
}
