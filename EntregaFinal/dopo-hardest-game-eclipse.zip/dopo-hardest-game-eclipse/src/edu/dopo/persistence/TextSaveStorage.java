package edu.dopo.persistence;

import java.io.BufferedReader;

import java.nio.file.Files;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import edu.dopo.application.SaveStorage;
import edu.dopo.domain.model.GameException;

public class TextSaveStorage implements SaveStorage {
    public void save(File file, SaveState state) throws GameException {
        try {
        	PrintWriter writer = new PrintWriter(Files.newBufferedWriter(file.toPath()));
            writer.println("level=" + state.getLevelName());
            writer.println("mode=" + state.getMode());
            writer.println("firstSkin=" + state.getFirstSkin());
            writer.println("secondSkin=" + state.getSecondSkin());
            writer.println("firstBorder=" + state.getFirstBorder());
            writer.println("secondBorder=" + state.getSecondBorder());
            writer.println("machine=" + state.getMachine());
            writer.println("remainingTime=" + state.getRemainingTime());
            for (String coin : state.getCollectedCoins()) {
                writer.println("collected=" + coin);
            }
            for (String element : state.getUsedElements()) {
                writer.println("used=" + element);
            }
            for (String player : state.getPlayerLines()) {
                writer.println("player=" + player);
            }
            writer.close();
        } catch (IOException e) {
            throw new GameException("No se pudo guardar la partida", e);
        }
    }

    public SaveState load(File file) throws GameException {
        try {
            String level = "";
            String mode = "PLAYER";
            String firstSkin = "BLINKY";
            String secondSkin = "INKY";
            String firstBorder = "BLANCO";
            String secondBorder = "NEGRO";
            String machine = "RANDOM";
            double remainingTime = 0;
            SaveState state = null;
            BufferedReader reader = Files.newBufferedReader(file.toPath());
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("level=")) {
                    level = value(line);
                } else if (line.startsWith("mode=")) {
                    mode = value(line);
                } else if (line.startsWith("firstSkin=")) {
                    firstSkin = value(line);
                } else if (line.startsWith("secondSkin=")) {
                    secondSkin = value(line);
                } else if (line.startsWith("firstBorder=")) {
                    firstBorder = value(line);
                } else if (line.startsWith("secondBorder=")) {
                    secondBorder = value(line);
                } else if (line.startsWith("machine=")) {
                    machine = value(line);
                } else if (line.startsWith("remainingTime=")) {
                    remainingTime = Double.parseDouble(value(line));
                    state = new SaveState(level, mode, firstSkin, secondSkin, firstBorder, secondBorder, machine, remainingTime);
                } else if (line.startsWith("collected=") && state != null) {
                    state.addCollectedCoin(value(line));
                } else if (line.startsWith("used=") && state != null) {
                    state.addUsedElement(value(line));
                } else if (line.startsWith("player=") && state != null) {
                    state.addPlayerLine(value(line));
                }
            }
            reader.close();
            if (state == null) {
                state = new SaveState(level, mode, firstSkin, secondSkin, firstBorder, secondBorder, machine, remainingTime);
            }
            return state;
        } catch (IOException e) {
            throw new GameException("No se pudo abrir la partida", e);
        }
    }

    private String value(String line) {
        return line.substring(line.indexOf('=') + 1).trim();
    }
}
