package edu.dopo.presentation;

import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.Map;

public class ColorPalette {
    private Map<String, Color> colors;

    public ColorPalette() {
        colors = new LinkedHashMap<String, Color>();
        colors.put("BLANCO", Color.WHITE);
        colors.put("NEGRO", Color.BLACK);
        colors.put("ROJO", new Color(220, 38, 38));
        colors.put("AZUL", new Color(37, 99, 235));
        colors.put("VERDE", new Color(22, 163, 74));
        colors.put("MORADO", new Color(126, 34, 206));
        colors.put("NARANJA", new Color(234, 88, 12));
    }

    public Color get(String key) {
        Color color = colors.get(key);
        if (color == null) {
            return Color.WHITE;
        }
        return color;
    }

    public String[] names() {
        return colors.keySet().toArray(new String[0]);
    }
}
