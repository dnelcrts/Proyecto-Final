package edu.dopo.presentation;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JPanel;

import edu.dopo.dto.GameSnapshot;
import edu.dopo.dto.RenderItem;

public class GameBoardPanel extends JPanel {
    private GameSnapshot snapshot;
    private ColorPalette palette;

    public GameBoardPanel(ColorPalette palette) {
        this.palette = palette;
        setBackground(new Color(14, 19, 33));
        setPreferredSize(new Dimension(760, 480));
        setFocusable(true);
    }

    public void show(GameSnapshot snapshot) {
        this.snapshot = snapshot;
        setPreferredSize(new Dimension(snapshot.getWidth(), snapshot.getHeight()));
        revalidate();
        repaint();
    }

    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawBackground(g);
        if (snapshot == null) {
            drawCentered(g, "The DOPO Hardest Game", getWidth() / 2, getHeight() / 2);
            return;
        }
        for (RenderItem item : snapshot.getRenderItems()) {
            drawItem(g, item);
        }
        if (!"RUNNING".equals(snapshot.getStatus())) {
            drawOverlay(g, snapshot.getStatus());
        }
    }

    private void drawBackground(Graphics2D g) {
        g.setColor(new Color(18, 24, 43));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(new Color(30, 41, 59));
        for (int x = 0; x < getWidth(); x += 32) {
            g.drawLine(x, 0, x, getHeight());
        }
        for (int y = 0; y < getHeight(); y += 32) {
            g.drawLine(0, y, getWidth(), y);
        }
    }

    private void drawItem(Graphics2D g, RenderItem item) {
        int x = (int) Math.round(item.getX());
        int y = (int) Math.round(item.getY());
        int w = (int) Math.round(item.getWidth());
        int h = (int) Math.round(item.getHeight());
        String key = item.getKey();
        if (key.startsWith("ZONE")) {
            g.setColor(new Color(34, 197, 94, 120));
            g.fill(new RoundRectangle2D.Double(x, y, w, h, 20, 20));
            g.setColor(new Color(187, 247, 208));
            g.setStroke(new BasicStroke(2));
            g.draw(new RoundRectangle2D.Double(x, y, w, h, 20, 20));
        } else if ("WALL".equals(key)) {
            g.setColor(new Color(71, 85, 105));
            g.fill(new RoundRectangle2D.Double(x, y, w, h, 10, 10));
            g.setColor(new Color(148, 163, 184));
            g.draw(new RoundRectangle2D.Double(x, y, w, h, 10, 10));
        } else if (key.startsWith("COIN_YELLOW")) {
            g.setColor(new Color(250, 204, 21));
            g.fill(new Ellipse2D.Double(x, y, w, h));
            g.setColor(new Color(254, 240, 138));
            g.draw(new Ellipse2D.Double(x, y, w, h));
        } else if (key.startsWith("COIN_SKIN")) {
            g.setColor(coinColor(key));
            g.fill(new Ellipse2D.Double(x, y, w, h));
            g.setColor(Color.WHITE);
            g.draw(new Ellipse2D.Double(x, y, w, h));
        } else if (key.startsWith("ENEMY")) {
            g.setColor(new Color(37, 99, 235));
            g.fill(new Ellipse2D.Double(x, y, w, h));
            g.setColor(new Color(191, 219, 254));
            g.setStroke(new BasicStroke(2));
            g.draw(new Ellipse2D.Double(x, y, w, h));
        } else if ("LIFE".equals(key)) {
            g.setColor(new Color(16, 185, 129));
            g.fill(new RoundRectangle2D.Double(x, y, w, h, 8, 8));
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 18));
            g.drawString("+", x + 6, y + 18);
        } else if ("BOMB".equals(key)) {
            g.setColor(new Color(15, 23, 42));
            g.fill(new Ellipse2D.Double(x, y, w, h));
            g.setColor(new Color(248, 113, 113));
            g.setFont(new Font("Arial", Font.BOLD, 14));
            g.drawString("B", x + 7, y + 17);
        } else if (key.startsWith("PLAYER")) {
            g.setColor(playerColor(key));
            g.fill(new RoundRectangle2D.Double(x, y, w, h, 8, 8));
            g.setColor(palette.get(item.getBorder()));
            g.setStroke(new BasicStroke(3));
            g.draw(new RoundRectangle2D.Double(x, y, w, h, 8, 8));
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 12));
            g.drawString(item.getLabel(), x + w / 2 - 4, y + h / 2 + 5);
        }
    }

    private Color playerColor(String key) {
        if (key.endsWith("INKY")) {
            return new Color(59, 130, 246);
        }
        if (key.endsWith("CLYDE")) {
            return new Color(34, 197, 94);
        }
        return new Color(239, 68, 68);
    }

    private Color coinColor(String key) {
        if (key.endsWith("INKY")) {
            return new Color(59, 130, 246);
        }
        if (key.endsWith("CLYDE")) {
            return new Color(34, 197, 94);
        }
        return new Color(239, 68, 68);
    }

    private void drawOverlay(Graphics2D g, String status) {
        g.setColor(new Color(2, 6, 23, 180));
        g.fillRect(0, 0, getWidth(), getHeight());
        String text = status;
        if ("PAUSED".equals(status)) {
            text = "PAUSA";
        } else if ("WON".equals(status)) {
            text = "VICTORIA";
        } else if ("LOST".equals(status)) {
            text = "TIEMPO AGOTADO";
        }
        drawCentered(g, text, getWidth() / 2, getHeight() / 2);
    }

    private void drawCentered(Graphics2D g, String text, int x, int y) {
        g.setFont(new Font("Arial", Font.BOLD, 38));
        int width = g.getFontMetrics().stringWidth(text);
        g.setColor(Color.WHITE);
        g.drawString(text, x - width / 2, y);
    }
}
