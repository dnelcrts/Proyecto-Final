package edu.dopo.presentation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import edu.dopo.application.ErrorSink;
import edu.dopo.application.GameSetup;
import edu.dopo.application.GameUseCase;
import edu.dopo.domain.model.GameException;
import edu.dopo.domain.model.GameModes;
import edu.dopo.dto.GameSnapshot;
import edu.dopo.dto.PlayerStatus;

public class MainWindow extends JFrame {
    private GameUseCase useCase;
    private ErrorSink errorSink;
    private ColorPalette palette;
    private MusicPlayer musicPlayer;
    private GameBoardPanel board;
    private JPanel menuPanel;
    private JPanel statusPanel;
    private JLabel timeLabel;
    private JLabel infoLabel;
    private JComboBox<String> levelBox;
    private JComboBox<String> modeBox;
    private JComboBox<String> firstSkinBox;
    private JComboBox<String> secondSkinBox;
    private JComboBox<String> firstBorderBox;
    private JComboBox<String> secondBorderBox;
    private JComboBox<String> machineBox;
    private JCheckBox musicBox;
    private Timer timer;
    private Set<Integer> keys;

    public MainWindow(GameUseCase useCase, ErrorSink errorSink) throws GameException {
        this.useCase = useCase;
        this.errorSink = errorSink;
        this.palette = new ColorPalette();
        this.musicPlayer = new MusicPlayer();
        this.keys = new HashSet<Integer>();
        prepareFrame();
        prepareMenu();
        prepareBoard();
        prepareStatus();
        addSaveButton();
        prepareActions();
        showMenu();
    }

    private void prepareFrame() {
        setTitle("The DOPO Hardest Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(15, 23, 42));
        setMinimumSize(new Dimension(980, 680));
        setLocationRelativeTo(null);
    }

    private void prepareMenu() throws GameException {
        menuPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        menuPanel.setBackground(new Color(15, 23, 42));
        levelBox = combo(useCase.levelNames());
        modeBox = combo(useCase.modeNames());
        firstSkinBox = combo(useCase.skinNames());
        secondSkinBox = combo(useCase.skinNames());
        firstBorderBox = new JComboBox<String>(palette.names());
        secondBorderBox = new JComboBox<String>(palette.names());
        machineBox = combo(useCase.machineNames());
        musicBox = new JCheckBox("Activar música", true);
        musicBox.setForeground(Color.WHITE);
        musicBox.setBackground(new Color(15, 23, 42));
        JButton startButton = button("Iniciar partida");
        JButton openButton = button("Abrir partida");
        addRow("Configuración", levelBox);
        addRow("Modalidad", modeBox);
        addRow("Skin jugador 1", firstSkinBox);
        addRow("Skin jugador 2", secondSkinBox);
        addRow("Borde jugador 1", firstBorderBox);
        addRow("Borde jugador 2", secondBorderBox);
        addRow("Máquina", machineBox);
        menuPanel.add(new JLabel(""));
        menuPanel.add(musicBox);
        menuPanel.add(startButton);
        menuPanel.add(openButton);
        startButton.addActionListener(e -> startGame());
        openButton.addActionListener(e -> openGame());
    }

    private JComboBox<String> combo(List<String> values) {
        return new JComboBox<String>(values.toArray(new String[0]));
    }

    private JButton button(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(37, 99, 235));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        return button;
    }

    private void addRow(String text, JComboBox<String> combo) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 13));
        menuPanel.add(label);
        menuPanel.add(combo);
    }

    private void prepareBoard() {
        board = new GameBoardPanel(palette);
    }

    private void prepareStatus() {
        statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        statusPanel.setBackground(new Color(2, 6, 23));
        timeLabel = new JLabel("Tiempo: 0");
        timeLabel.setForeground(Color.WHITE);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        infoLabel = new JLabel("WASD jugador 1 | Flechas jugador 2 | P pausa | ESC menú", SwingConstants.RIGHT);
        infoLabel.setForeground(new Color(203, 213, 225));
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        statusPanel.add(timeLabel, BorderLayout.WEST);
        statusPanel.add(infoLabel, BorderLayout.CENTER);
    }

    private void prepareActions() {
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(event -> {
            if (!isActive()) {
                return false;
            }
            if (event.getID() == KeyEvent.KEY_PRESSED) {
                keys.add(event.getKeyCode());
                if (event.getKeyCode() == KeyEvent.VK_P) {
                    useCase.pauseOrResume();
                    refresh();
                }
                if (event.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    useCase.finish();
                    stopLoop();
                    musicPlayer.stop();
                    showMenu();
                }
                updateDirections();
            }
            if (event.getID() == KeyEvent.KEY_RELEASED) {
                keys.remove(event.getKeyCode());
                updateDirections();
            }
            return false;
        });
    }

    private void startGame() {
        try {
            GameSetup setup = new GameSetup(selected(levelBox), selected(modeBox), selected(firstSkinBox), selected(secondSkinBox), selected(firstBorderBox), selected(secondBorderBox), selected(machineBox), musicBox.isSelected());
            useCase.start(setup);
            showGame(setup.hasMusic());
        } catch (GameException e) {
            showError(e);
        }
    }

    private String selected(JComboBox<String> box) {
        return String.valueOf(box.getSelectedItem());
    }

    private void showGame(boolean music) {
        getContentPane().removeAll();
        add(statusPanel, BorderLayout.NORTH);
        add(board, BorderLayout.CENTER);
        revalidate();
        repaint();
        if (music) {
            musicPlayer.start();
        } else {
            musicPlayer.stop();
        }
        startLoop();
        requestFocusInWindow();
    }

    private void showMenu() {
        getContentPane().removeAll();
        JLabel title = new JLabel("The DOPO Hardest Game", SwingConstants.CENTER);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 34));
        title.setBorder(BorderFactory.createEmptyBorder(28, 10, 10, 10));
        add(title, BorderLayout.NORTH);
        add(menuPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
        requestFocusInWindow();
    }

    private void startLoop() {
        stopLoop();
        timer = new Timer(16, e -> loop());
        timer.start();
    }

    private void stopLoop() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
    }

    private void loop() {
        try {
            updateDirections();
            useCase.tick(0.016);
            refresh();
        } catch (GameException e) {
            stopLoop();
            showError(e);
        }
    }

    private void updateDirections() {
        try {
            double x1 = 0;
            double y1 = 0;
            if (keys.contains(KeyEvent.VK_A)) {
                x1 -= 1;
            }
            if (keys.contains(KeyEvent.VK_D)) {
                x1 += 1;
            }
            if (keys.contains(KeyEvent.VK_W)) {
                y1 -= 1;
            }
            if (keys.contains(KeyEvent.VK_S)) {
                y1 += 1;
            }
            useCase.setDirection(1, x1, y1);
            double x2 = 0;
            double y2 = 0;
            if (keys.contains(KeyEvent.VK_LEFT)) {
                x2 -= 1;
            }
            if (keys.contains(KeyEvent.VK_RIGHT)) {
                x2 += 1;
            }
            if (keys.contains(KeyEvent.VK_UP)) {
                y2 -= 1;
            }
            if (keys.contains(KeyEvent.VK_DOWN)) {
                y2 += 1;
            }
            GameSnapshot snapshot = useCase.snapshot();
            if (snapshot.getPlayerStatus().size() > 1 && !GameModes.PLAYER_VS_MACHINE.equals(selected(modeBox))) {
                useCase.setDirection(2, x2, y2);
            }
        } catch (GameException e) {
        }
    }

    private void refresh() {
        GameSnapshot snapshot = useCase.snapshot();
        board.show(snapshot);
        timeLabel.setText("Tiempo: " + (int) Math.ceil(snapshot.getRemainingTime()));
        StringBuilder builder = new StringBuilder();
        for (PlayerStatus status : snapshot.getPlayerStatus()) {
            builder.append("J").append(status.getNumber()).append(" monedas ").append(status.getCoins()).append("/").append(snapshot.getTotalCoins()).append(" muertes ").append(status.getDeaths()).append(" vidas ").append(status.getLives()).append("   ");
        }
        builder.append(snapshot.getStatus());
        infoLabel.setText(builder.toString());
        if ("WON".equals(snapshot.getStatus()) || "LOST".equals(snapshot.getStatus())) {
            stopLoop();
        }
    }

    private void openGame() {
        try {
            JFileChooser chooser = new JFileChooser(new File("data/saves"));
            int result = chooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                useCase.open(chooser.getSelectedFile());
                showGame(musicBox.isSelected());
            }
        } catch (GameException e) {
            showError(e);
        }
    }

    private void saveGame() {
        try {
            JFileChooser chooser = new JFileChooser(new File("data/saves"));
            int result = chooser.showSaveDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                useCase.save(chooser.getSelectedFile());
            }
        } catch (GameException e) {
            showError(e);
        }
    }

    public void addSaveButton() {
        JButton saveButton = button("Guardar");
        saveButton.addActionListener(e -> saveGame());
        statusPanel.add(saveButton, BorderLayout.EAST);
    }

    private void showError(Exception e) {
        errorSink.write(e);
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
