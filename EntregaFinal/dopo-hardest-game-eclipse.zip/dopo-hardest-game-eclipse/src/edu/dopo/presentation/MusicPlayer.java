package edu.dopo.presentation;

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;
import javax.swing.Timer;

public class MusicPlayer {
    private Synthesizer synthesizer;
    private MidiChannel channel;
    private Timer timer;
    private int index;
    private int[] notes;

    public MusicPlayer() {
        notes = new int[] { 72, 76, 79, 84, 79, 76, 74, 77, 81, 86, 81, 77 };
        index = 0;
    }

    public void start() {
        try {
            if (synthesizer == null) {
                synthesizer = MidiSystem.getSynthesizer();
                synthesizer.open();
                Instrument[] instruments = synthesizer.getDefaultSoundbank().getInstruments();
                synthesizer.loadInstrument(instruments[0]);
                channel = synthesizer.getChannels()[0];
                channel.programChange(80);
            }
            stopTimer();
            timer = new Timer(230, e -> playNext());
            timer.start();
        } catch (Exception e) {
            stop();
        }
    }

    private void playNext() {
        if (channel == null) {
            return;
        }
        int note = notes[index % notes.length];
        channel.noteOn(note, 55);
        Timer off = new Timer(150, e -> channel.noteOff(note));
        off.setRepeats(false);
        off.start();
        index++;
    }

    public void stop() {
        stopTimer();
        if (synthesizer != null) {
            synthesizer.close();
            synthesizer = null;
            channel = null;
        }
    }

    private void stopTimer() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
    }
}
