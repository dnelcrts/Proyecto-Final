package edu.dopo.acceptance;

import java.io.File;

import edu.dopo.application.GameApplication;
import edu.dopo.application.GameSetup;
import edu.dopo.application.GameUseCase;
import edu.dopo.application.LevelSource;
import edu.dopo.application.SaveStorage;
import edu.dopo.domain.factory.MachineCatalog;
import edu.dopo.domain.factory.SkinCatalog;
import edu.dopo.domain.model.GameModes;
import edu.dopo.dto.GameSnapshot;
import edu.dopo.persistence.TextLevelSource;
import edu.dopo.persistence.TextSaveStorage;

public class AcceptanceTest {
    public static void main(String[] args) throws Exception {
        SkinCatalog skins = new SkinCatalog();
        MachineCatalog machines = new MachineCatalog();
        LevelSource levels = new TextLevelSource(new File("data/configs"), skins);
        SaveStorage saves = new TextSaveStorage();
        GameUseCase app = new GameApplication(levels, saves, skins, machines);
        String level = app.levelNames().get(0);
        app.start(new GameSetup(level, GameModes.PLAYER, "BLINKY", "INKY", "BLANCO", "NEGRO", "RANDOM", false));
        app.setDirection(1, 1, 0);
        for (int i = 0; i < 20; i++) {
            app.tick(0.016);
        }
        GameSnapshot snapshot = app.snapshot();
        if (snapshot.getWidth() <= 0 || snapshot.getRenderItems().isEmpty()) {
            throw new IllegalStateException("Prueba de aceptación fallida");
        }
        File save = new File("data/saves/acceptance-save.txt");
        app.save(save);
        app.open(save);
        System.out.println("Pruebas de aceptación ejecutadas correctamente");
    }
}
