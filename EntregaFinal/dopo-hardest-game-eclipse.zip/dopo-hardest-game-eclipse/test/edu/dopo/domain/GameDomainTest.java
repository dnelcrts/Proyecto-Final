package edu.dopo.domain;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import edu.dopo.domain.model.GameException;
import edu.dopo.domain.service.CollisionService;
import edu.dopo.application.GameApplication;
import edu.dopo.application.GameSetup;
import edu.dopo.application.GameUseCase;
import edu.dopo.domain.ai.ExpertMachineStrategy;
import edu.dopo.domain.ai.RandomMachineStrategy;
import edu.dopo.domain.factory.CoinCatalog;
import edu.dopo.domain.factory.EnemyCatalog;
import edu.dopo.domain.factory.MachineCatalog;
import edu.dopo.domain.factory.SkinCatalog;
import edu.dopo.domain.factory.SpecialCatalog;
import edu.dopo.domain.model.Bomb;
import edu.dopo.domain.model.FastEnemy;
import edu.dopo.domain.model.Game;
import edu.dopo.domain.model.GameModes;
import edu.dopo.domain.model.GameStatus;
import edu.dopo.domain.model.Level;
import edu.dopo.domain.model.LifeSource;
import edu.dopo.domain.model.LinearEnemy;
import edu.dopo.domain.model.PatrolEnemy;
import edu.dopo.domain.model.Rect;
import edu.dopo.domain.model.SkinCoin;
import edu.dopo.domain.model.Vector2;
import edu.dopo.domain.model.VerticalSliderEnemy;
import edu.dopo.domain.model.Wall;
import edu.dopo.domain.model.YellowCoin;
import edu.dopo.domain.model.Zone;
import edu.dopo.domain.model.ZoneKinds;
import edu.dopo.dto.GameSnapshot;
import edu.dopo.dto.PlayerStatus;
import edu.dopo.dto.RenderItem;
import edu.dopo.persistence.SaveState;
import edu.dopo.persistence.TextErrorSink;
import edu.dopo.persistence.TextSaveStorage;
import edu.dopo.presentation.ColorPalette;

public class GameDomainTest {

    @Rule
    public TemporaryFolder tmp = new TemporaryFolder();

    // ═══════════════════════════════════════════════════════
    // PRUEBAS ORIGINALES
    // ═══════════════════════════════════════════════════════

    @Test
    public void playerCollectsCoin() throws Exception {
        Level level = baseLevel();
        level.addCoin(new YellowCoin("c1", 40, 40));
        Game game = makeGame(level, GameModes.PLAYER, "BLINKY");
        game.tick(0.02);
        assertEquals(1, game.player(1).getCollectedCoins());
    }

    @Test
    public void playerWinsAfterCoinsAndEndZone() throws Exception {
        Level level = baseLevel();
        level.addCoin(new YellowCoin("c1", 40, 40));
        Game game = makeGame(level, GameModes.PLAYER, "BLINKY");
        game.tick(0.02);
        game.player(1).setPosition(360, 40);
        game.tick(0.02);
        assertEquals(GameStatus.WON, game.getStatus());
    }

    @Test
    public void clydeAbsorbsFirstHit() throws Exception {
        Game game = makeGame(baseLevel(), GameModes.PLAYER, "CLYDE");
        assertFalse(game.player(1).hitByEnemy());
        assertEquals(0, game.player(1).getDeaths());
    }

    @Test
    public void machineCatalogCreatesExpert() throws Exception {
        assertEquals("EXPERT", new MachineCatalog().create("EXPERT").key());
    }

    // ═══════════════════════════════════════════════════════
    // VECTOR2
    // ═══════════════════════════════════════════════════════

    @Test public void vector2Getters() {
        Vector2 v = new Vector2(3.0, 4.0);
        assertEquals(3.0, v.getX(), 0.001); assertEquals(4.0, v.getY(), 0.001);
    }
    @Test public void vector2Length() { assertEquals(5.0, new Vector2(3.0, 4.0).length(), 0.001); }
    @Test public void vector2NormalizedLengthOne() { assertEquals(1.0, new Vector2(3.0, 4.0).normalized().length(), 0.001); }
    @Test public void vector2ZeroNormalized() {
        Vector2 v = new Vector2(0,0).normalized();
        assertEquals(0.0, v.getX(), 0.001); assertEquals(0.0, v.getY(), 0.001);
    }
    @Test public void vector2Plus() {
        Vector2 r = new Vector2(1,2).plus(new Vector2(3,4));
        assertEquals(4.0, r.getX(), 0.001); assertEquals(6.0, r.getY(), 0.001);
    }
    @Test public void vector2Minus() {
        Vector2 r = new Vector2(5,7).minus(new Vector2(2,3));
        assertEquals(3.0, r.getX(), 0.001); assertEquals(4.0, r.getY(), 0.001);
    }
    @Test public void vector2Times() {
        Vector2 r = new Vector2(2,3).times(4);
        assertEquals(8.0, r.getX(), 0.001); assertEquals(12.0, r.getY(), 0.001);
    }
    @Test public void vector2Set() {
        Vector2 v = new Vector2(1,1); v.set(9,8);
        assertEquals(9.0, v.getX(), 0.001); assertEquals(8.0, v.getY(), 0.001);
    }
    @Test public void vector2CopyIndependent() {
        Vector2 o = new Vector2(5,6); o.copy().set(0,0); assertEquals(5.0, o.getX(), 0.001);
    }

    // ═══════════════════════════════════════════════════════
    // RECT
    // ═══════════════════════════════════════════════════════

    @Test public void rectIntersects() { assertTrue(new Rect(0,0,10,10).intersects(new Rect(5,5,10,10))); }
    @Test public void rectNoIntersect() { assertFalse(new Rect(0,0,5,5).intersects(new Rect(10,10,5,5))); }
    @Test public void rectContains() { assertTrue(new Rect(0,0,100,100).contains(new Rect(10,10,20,20))); }
    @Test public void rectNotContains() { assertFalse(new Rect(10,10,5,5).contains(new Rect(0,0,100,100))); }
    @Test public void rectContainsPoint() { assertTrue(new Rect(0,0,50,50).containsPoint(25,25)); }
    @Test public void rectNotContainsPoint() { assertFalse(new Rect(0,0,50,50).containsPoint(100,100)); }
    @Test public void rectCenter() {
        Rect r = new Rect(0,0,100,60);
        assertEquals(50.0, r.centerX(), 0.001); assertEquals(30.0, r.centerY(), 0.001);
    }

    // ═══════════════════════════════════════════════════════
    // LEVEL
    // ═══════════════════════════════════════════════════════

    @Test public void levelGetters() {
        Level l = new Level("T", 800, 600, 120);
        assertEquals("T", l.getName()); assertEquals(800, l.getWidth());
        assertEquals(600, l.getHeight()); assertEquals(120, l.getTimeLimit());
    }
    @Test public void levelAllCoinsEmpty() { assertTrue(new Level("L",400,300,60).allCoinsCollected()); }
    @Test public void levelNotAllCoins() {
        Level l = new Level("L",400,300,60); l.addCoin(new YellowCoin("c1",10,10));
        assertFalse(l.allCoinsCollected());
    }
    @Test public void levelTotalCoins() {
        Level l = new Level("L",400,300,60);
        l.addCoin(new YellowCoin("c1",10,10)); l.addCoin(new YellowCoin("c2",20,20));
        assertEquals(2, l.totalCoins());
    }
    @Test(expected = Exception.class) public void levelZoneForThrows() throws Exception {
        new Level("L",400,300,60).zoneFor("END",1);
    }
    @Test public void levelZoneForFallbackToPlayer1() throws Exception {
        Level l = new Level("L",400,300,60);
        l.addZone(new Zone("z1", ZoneKinds.END, 1, 100,100,50,50));
        assertEquals(1, l.zoneFor(ZoneKinds.END,2).getPlayerNumber());
    }

    // ═══════════════════════════════════════════════════════
    // PLAYER
    // ═══════════════════════════════════════════════════════

    @Test public void playerHitIncreasesDeaths() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.player(1).hitByEnemy(); assertEquals(1, g.player(1).getDeaths());
    }
    @Test public void playerExtraLifeSurvives() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.player(1).addLife(); assertFalse(g.player(1).hitByEnemy());
        assertEquals(0, g.player(1).getDeaths()); assertEquals(0, g.player(1).getLives());
    }
    @Test public void playerForceDeath() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.player(1).forceDeath(); assertEquals(1, g.player(1).getDeaths());
    }
    @Test public void playerSetDirection() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.player(1).setDirection(1,0); assertEquals(1.0, g.player(1).getDirection().getX(), 0.001);
    }
    @Test public void playerCompletionCycle() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        assertFalse(g.player(1).isCompleted()); g.player(1).complete();
        assertTrue(g.player(1).isCompleted()); g.player(1).resetCompletion();
        assertFalse(g.player(1).isCompleted());
    }
    @Test public void playerSetCollectedCoins() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.player(1).setCollectedCoins(5); assertEquals(5, g.player(1).getCollectedCoins());
    }
    @Test public void playerSetDeaths() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.player(1).setDeaths(3); assertEquals(3, g.player(1).getDeaths());
    }
    @Test public void playerOriginalSkin() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        assertEquals("BLINKY", g.player(1).getOriginalSkinKey());
    }
    @Test public void playerSetLives() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.player(1).setLives(2); assertEquals(2, g.player(1).getLives());
    }
    @Test public void playerBorderName() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        assertEquals("BLANCO", g.player(1).getBorderName());
    }
    @Test public void playerSpawn() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        assertEquals(40.0, g.player(1).getSpawn().getX(), 0.001);
    }
    @Test public void playerRenderKey() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        assertEquals("PLAYER_BLINKY", g.player(1).renderKey());
    }
    @Test public void playerClydeWeakenedThenDies() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "CLYDE");
        g.player(1).hitByEnemy(); assertTrue(g.player(1).isWeakened());
        assertTrue(g.player(1).hitByEnemy()); assertEquals(1, g.player(1).getDeaths());
    }
    @Test public void playerMovesWhenDirectionSet() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        double x0 = g.player(1).getX(); g.player(1).setDirection(1,0); g.tick(0.1);
        assertTrue(g.player(1).getX() > x0);
    }

    // ═══════════════════════════════════════════════════════
    // GAME
    // ═══════════════════════════════════════════════════════

    @Test public void gameInitialRunning() throws Exception {
        assertEquals(GameStatus.RUNNING, makeGame(baseLevel(), GameModes.PLAYER, "BLINKY").getStatus());
    }
    @Test public void gameTimerExpires() throws Exception {
        Level l = new Level("T",420,180,1);
        l.addZone(new Zone("s1",ZoneKinds.START,1,40,40,60,60));
        l.addZone(new Zone("e1",ZoneKinds.END,1,360,40,50,60));
        l.addWall(new Wall("w1",0,0,420,10));
        Game g = makeGame(l, GameModes.PLAYER, "BLINKY"); g.tick(2.0);
        assertEquals(GameStatus.LOST, g.getStatus());
    }
    @Test public void gameTickIgnoredWhenNotRunning() throws Exception {
        Level l = baseLevel(); l.addCoin(new YellowCoin("c1",40,40));
        Game g = makeGame(l, GameModes.PLAYER, "BLINKY"); g.tick(0.02);
        g.player(1).setPosition(360,40); g.tick(0.02);
        assertEquals(GameStatus.WON, g.getStatus()); g.tick(0.5);
        assertEquals(GameStatus.WON, g.getStatus());
    }
    @Test public void gamePauseResume() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.pause(); assertEquals(GameStatus.PAUSED, g.getStatus());
        g.resume(); assertEquals(GameStatus.RUNNING, g.getStatus());
    }
    @Test public void gamePauseOnlyWhenRunning() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.pause(); g.pause(); assertEquals(GameStatus.PAUSED, g.getStatus());
    }
    @Test public void gameResumeOnlyWhenPaused() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.resume(); assertEquals(GameStatus.RUNNING, g.getStatus());
    }
    @Test public void gameFinish() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.finish(); assertEquals(GameStatus.MENU, g.getStatus());
    }
    @Test public void gameSetStatus() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.setStatus(GameStatus.PAUSED); assertEquals(GameStatus.PAUSED, g.getStatus());
    }
    @Test public void gameMode() throws Exception {
        assertEquals(GameModes.PLAYER, makeGame(baseLevel(), GameModes.PLAYER, "BLINKY").getMode());
    }
    @Test public void gameRemainingTime() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        g.setRemainingTime(30.0); assertEquals(30.0, g.getRemainingTime(), 0.001);
    }
    @Test public void gameGetPlayers() throws Exception {
        assertEquals(1, makeGame(baseLevel(), GameModes.PLAYER, "BLINKY").getPlayers().size());
    }
    @Test(expected = Exception.class) public void gamePlayerInvalidNumber() throws Exception {
        makeGame(baseLevel(), GameModes.PLAYER, "BLINKY").player(99);
    }
    @Test public void gameVsPlayer2Players() throws Exception {
        assertEquals(2, makeGame2P(baseLevelTwoPlayers(), GameModes.PLAYER_VS_PLAYER).getPlayers().size());
    }
    @Test public void gameVsMachineRandom() throws Exception {
        Game g = new Game(baseLevelTwoPlayers(), GameModes.PLAYER_VS_MACHINE,
                new SkinCatalog().create("BLINKY"), new SkinCatalog().create("INKY"),
                "BLANCO","NEGRO", new MachineCatalog().create("RANDOM"));
        g.player(1).setDirection(1,0); g.tick(0.02);
        assertEquals(GameStatus.RUNNING, g.getStatus());
    }
    @Test public void gameVsMachineExpert() throws Exception {
        Level l = baseLevelTwoPlayers(); l.addCoin(new YellowCoin("c1",200,90));
        Game g = new Game(l, GameModes.PLAYER_VS_MACHINE,
                new SkinCatalog().create("BLINKY"), new SkinCatalog().create("INKY"),
                "BLANCO","NEGRO", new MachineCatalog().create("EXPERT"));
        g.tick(0.02); assertEquals(GameStatus.RUNNING, g.getStatus());
    }
    @Test public void gameWithEnemy() throws Exception {
        Level l = baseLevel(); l.addCoin(new YellowCoin("c1",300,100));
        l.addEnemy(new LinearEnemy("e1",200,100,20,1,0,50));
        makeGame(l, GameModes.PLAYER, "BLINKY").tick(0.02);
    }
    @Test public void gameVsPlayerOneCompletes() throws Exception {
        Level l = baseLevelTwoPlayers(); l.addCoin(new YellowCoin("c1",40,40));
        Game g = makeGame2P(l, GameModes.PLAYER_VS_PLAYER);
        g.player(1).complete(); g.tick(0.02);
        assertEquals(GameStatus.WON, g.getStatus());
    }
    @Test public void gameDoesNotMoveWithZeroDirection() throws Exception {
        Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
        double x = g.player(1).getX(); g.tick(0.1); assertEquals(x, g.player(1).getX(), 0.001);
    }
    @Test public void gameGetLevel() throws Exception {
        Level l = baseLevel();
        assertEquals(l, makeGame(l, GameModes.PLAYER, "BLINKY").getLevel());
    }

    // ═══════════════════════════════════════════════════════
    // ENEMIES
    // ═══════════════════════════════════════════════════════

    @Test public void linearEnemyMovesRight() {
        Level l = enemyLevel(); LinearEnemy e = new LinearEnemy("e1",50,100,20,1,0,100);
        double x0 = e.getX(); e.move(l,0.1); assertTrue(e.getX() > x0);
    }
    @Test public void linearEnemyBouncesAtBorder() {
        // Place enemy near right border moving right — it must bounce
        Level l = new Level("L",130,300,60);
        LinearEnemy e = new LinearEnemy("e1",100,100,20,1,0,200);
        e.move(l,0.5);
        // After bouncing, direction reversed; position should be <= starting
        assertTrue(e.getX() <= 110);
    }
    @Test public void linearEnemyRenderKey() {
        assertEquals("ENEMY_BASIC", new LinearEnemy("e1",50,50,20,1,0,100).renderKey());
    }
    @Test public void linearEnemyInactiveNoMove() {
        Level l = enemyLevel(); LinearEnemy e = new LinearEnemy("e1",100,100,20,1,0,100);
        e.deactivate(); double x = e.getX(); e.move(l,1.0); assertEquals(x, e.getX(), 0.001);
    }
    @Test public void fastEnemyRenderKey() { assertEquals("ENEMY_FAST", new FastEnemy("e1",50,50,20,1,0,100).renderKey()); }
    @Test public void fastEnemyMoves() {
        FastEnemy e = new FastEnemy("e1",50,100,20,1,0,100);
        double x0 = e.getX(); e.move(enemyLevel(),0.1); assertTrue(e.getX() > x0);
    }
    @Test public void verticalEnemyRenderKey() { assertEquals("ENEMY_VERTICAL", new VerticalSliderEnemy("e1",50,50,20,100).renderKey()); }
    @Test public void verticalEnemyMoves() {
        VerticalSliderEnemy e = new VerticalSliderEnemy("e1",100,50,20,100);
        double y0 = e.getY(); e.move(enemyLevel(),0.1); assertTrue(e.getY() > y0);
    }
    @Test public void patrolEnemyMoves() {
        List<Vector2> pts = new ArrayList<Vector2>();
        pts.add(new Vector2(200,100)); pts.add(new Vector2(100,100));
        PatrolEnemy e = new PatrolEnemy("e1",100,100,20,100,pts);
        e.move(enemyLevel(),0.5);
    }
    @Test public void patrolEnemyInactiveNoMove() {
        List<Vector2> pts = new ArrayList<Vector2>(); pts.add(new Vector2(200,100));
        PatrolEnemy e = new PatrolEnemy("e1",100,100,20,100,pts);
        e.deactivate(); double x = e.getX(); e.move(enemyLevel(),1.0); assertEquals(x, e.getX(), 0.001);
    }
    @Test public void patrolEnemyAdvancesTarget() {
        List<Vector2> pts = new ArrayList<Vector2>();
        pts.add(new Vector2(101,100)); pts.add(new Vector2(200,100));
        PatrolEnemy e = new PatrolEnemy("e1",100,100,20,100,pts);
        e.move(enemyLevel(),0.1); // close to first target → switches
    }
    @Test public void patrolEnemyRenderKey() {
        List<Vector2> pts = new ArrayList<Vector2>(); pts.add(new Vector2(100,100));
        assertEquals("ENEMY_PATROL", new PatrolEnemy("e1",50,50,20,100,pts).renderKey());
    }

    // ═══════════════════════════════════════════════════════
    // SPECIAL ELEMENTS
    // ═══════════════════════════════════════════════════════

    @Test public void lifeSourceAddsLife() throws Exception {
        Level l = baseLevel(); l.addSpecialElement(new LifeSource("ls1",40,40));
        Game g = makeGame(l, GameModes.PLAYER, "BLINKY"); g.tick(0.02);
        assertEquals(1, g.player(1).getLives());
    }
    @Test public void lifeSourceRenderKey() { assertEquals("LIFE", new LifeSource("ls1",0,0).renderKey()); }
    @Test public void lifeSourceNoAffectEnemies() { assertFalse(new LifeSource("ls1",0,0).affectsEnemies()); }
    @Test public void bombKillsPlayer() throws Exception {
        Level l = baseLevel(); l.addSpecialElement(new Bomb("b1",40,40));
        Game g = makeGame(l, GameModes.PLAYER, "BLINKY"); g.tick(0.02);
        assertEquals(1, g.player(1).getDeaths());
    }
    @Test public void bombRenderKey() { assertEquals("BOMB", new Bomb("b1",0,0).renderKey()); }
    @Test public void bombAffectsEnemies() { assertTrue(new Bomb("b1",0,0).affectsEnemies()); }
    @Test public void bombDeactivatesEnemy() throws Exception {
        Level l = baseLevel(); l.addSpecialElement(new Bomb("b1",200,80));
        l.addEnemy(new LinearEnemy("e1",200,80,20,0,0,0));
        makeGame(l, GameModes.PLAYER, "BLINKY").tick(0.02);
        assertFalse(l.getEnemies().get(0).isActive());
    }
    @Test public void skinCoinChangesSkin() throws Exception {
        Level l = baseLevel(); l.addCoin(new SkinCoin("sc1",40,40,"CLYDE",new SkinCatalog()));
        Game g = makeGame(l, GameModes.PLAYER, "BLINKY"); g.tick(0.02);
        assertEquals("CLYDE", g.player(1).getSkinKey());
    }

    // ═══════════════════════════════════════════════════════
    // FACTORIES
    // ═══════════════════════════════════════════════════════

    @Test public void machineCatalogRandom() throws Exception { assertEquals("RANDOM", new MachineCatalog().create("RANDOM").key()); }
    @Test public void skinCatalogBlinky() throws Exception { assertEquals("BLINKY", new SkinCatalog().create("BLINKY").key()); }
    @Test public void skinCatalogClyde() throws Exception { assertEquals("CLYDE", new SkinCatalog().create("CLYDE").key()); }
    @Test public void skinCatalogInky() throws Exception { assertEquals("INKY", new SkinCatalog().create("INKY").key()); }
    @Test public void coinCatalogYellow() throws Exception { assertNotNull(new CoinCatalog(new SkinCatalog()).create(new String[]{"yellow","c1","10","20"})); }
    @Test public void coinCatalogSkin() throws Exception { assertNotNull(new CoinCatalog(new SkinCatalog()).create(new String[]{"skin","c2","10","20","BLINKY"})); }
    @Test(expected=Exception.class) public void coinCatalogUnknown() throws Exception { new CoinCatalog(new SkinCatalog()).create(new String[]{"unknown","x","0","0"}); }
    @Test public void enemyCatalogLinear() throws Exception { assertNotNull(new EnemyCatalog().create(new String[]{"linear","e1","100","100","20","1","0","100"})); }
    @Test public void enemyCatalogFast() throws Exception { assertNotNull(new EnemyCatalog().create(new String[]{"fast","e1","100","100","20","1","0","200"})); }
    @Test public void enemyCatalogVertical() throws Exception { assertNotNull(new EnemyCatalog().create(new String[]{"vertical","e1","100","100","20","100"})); }
    @Test public void enemyCatalogPatrol() throws Exception { assertNotNull(new EnemyCatalog().create(new String[]{"patrol","e1","100","100","20","100","50:50|100:100"})); }
    @Test(expected=Exception.class) public void enemyCatalogUnknown() throws Exception { new EnemyCatalog().create(new String[]{"unknown","e1","0","0","10","1","0","50"}); }
    @Test public void specialCatalogLife() throws Exception { assertNotNull(new SpecialCatalog().create(new String[]{"life","s1","50","50"})); }
    @Test public void specialCatalogBomb() throws Exception { assertNotNull(new SpecialCatalog().create(new String[]{"bomb","b1","50","50"})); }
    @Test(expected=Exception.class) public void specialCatalogUnknown() throws Exception { new SpecialCatalog().create(new String[]{"unknown","x","0","0"}); }

    // ═══════════════════════════════════════════════════════
    // AI
    // ═══════════════════════════════════════════════════════

    @Test public void randomKey() { assertEquals("RANDOM", new RandomMachineStrategy().key()); }
    @Test public void randomName() { assertNotNull(new RandomMachineStrategy().name()); }
    @Test public void expertKey() { assertEquals("EXPERT", new ExpertMachineStrategy().key()); }
    @Test public void expertName() { assertNotNull(new ExpertMachineStrategy().name()); }
    @Test public void expertDecideNoCoins() throws Exception {
        Game g = new Game(baseLevelTwoPlayers(), GameModes.PLAYER_VS_MACHINE,
                new SkinCatalog().create("BLINKY"), new SkinCatalog().create("INKY"),
                "BLANCO","NEGRO", new MachineCatalog().create("EXPERT"));
        g.tick(0.05);
    }
    @Test public void expertDecideWithCoin() throws Exception {
        Level l = baseLevelTwoPlayers(); l.addCoin(new YellowCoin("c1",150,90));
        Game g = new Game(l, GameModes.PLAYER_VS_MACHINE,
                new SkinCatalog().create("BLINKY"), new SkinCatalog().create("INKY"),
                "BLANCO","NEGRO", new MachineCatalog().create("EXPERT"));
        g.tick(0.05);
    }

    // ═══════════════════════════════════════════════════════
    // ZONE
    // ═══════════════════════════════════════════════════════

    @Test public void zoneGetters() {
        Zone z = new Zone("z1",ZoneKinds.START,1,10,20,50,60);
        assertEquals("z1",z.getId()); assertEquals(ZoneKinds.START,z.getKind()); assertEquals(1,z.getPlayerNumber());
    }
    @Test public void zoneRenderKeys() {
        assertEquals("ZONE_START",  new Zone("a",ZoneKinds.START, 1,0,0,10,10).renderKey());
        assertEquals("ZONE_END",    new Zone("b",ZoneKinds.END,   1,0,0,10,10).renderKey());
        assertEquals("ZONE_MIDDLE", new Zone("c",ZoneKinds.MIDDLE,1,0,0,10,10).renderKey());
    }
    @Test public void middleZoneCheckpoint() throws Exception {
        Level l = baseLevel(); l.addZone(new Zone("mid",ZoneKinds.MIDDLE,1,40,40,60,60));
        Game g = makeGame(l, GameModes.PLAYER, "BLINKY"); g.tick(0.02);
        assertEquals(40.0, g.player(1).getSpawn().getX(), 0.001);
    }

    // ═══════════════════════════════════════════════════════
    // DTO — GameSnapshot, PlayerStatus, RenderItem
    // ═══════════════════════════════════════════════════════

    @Test public void gameSnapshotGetters() {
        GameSnapshot s = new GameSnapshot("Level1",800,600,"RUNNING",30.0,5);
        assertEquals("Level1", s.getLevelName()); assertEquals(800, s.getWidth());
        assertEquals(600, s.getHeight()); assertEquals("RUNNING", s.getStatus());
        assertEquals(30.0, s.getRemainingTime(), 0.001); assertEquals(5, s.getTotalCoins());
    }
    @Test public void gameSnapshotAddItem() {
        GameSnapshot s = new GameSnapshot("L",400,300,"RUNNING",60,0);
        s.addItem(new RenderItem("KEY",10,20,30,40,"label","border"));
        assertEquals(1, s.getRenderItems().size());
    }
    @Test public void gameSnapshotAddPlayerStatus() {
        GameSnapshot s = new GameSnapshot("L",400,300,"RUNNING",60,0);
        s.addPlayerStatus(new PlayerStatus(1,0,2,1,"BLINKY",false));
        assertEquals(1, s.getPlayerStatus().size());
    }
    @Test public void playerStatusGetters() {
        PlayerStatus ps = new PlayerStatus(2,3,4,1,"CLYDE",true);
        assertEquals(2, ps.getNumber()); assertEquals(3, ps.getDeaths());
        assertEquals(4, ps.getCoins()); assertEquals(1, ps.getLives());
        assertEquals("CLYDE", ps.getSkin()); assertTrue(ps.isCompleted());
    }
    @Test public void renderItemGetters() {
        RenderItem r = new RenderItem("COIN",10,20,18,18,"","");
        assertEquals("COIN",r.getKey()); assertEquals(10,r.getX(),0.001);
        assertEquals(20,r.getY(),0.001); assertEquals(18,r.getWidth(),0.001);
        assertEquals(18,r.getHeight(),0.001); assertEquals("",r.getLabel()); assertEquals("",r.getBorder());
    }

    // ═══════════════════════════════════════════════════════
    // PERSISTENCE — SaveState, TextSaveStorage, TextErrorSink
    // ═══════════════════════════════════════════════════════

    @Test public void saveStateGetters() {
        SaveState s = new SaveState("Lv1","PLAYER","BLINKY","INKY","BLANCO","NEGRO","RANDOM",45.0);
        assertEquals("Lv1",s.getLevelName()); assertEquals("PLAYER",s.getMode());
        assertEquals("BLINKY",s.getFirstSkin()); assertEquals("INKY",s.getSecondSkin());
        assertEquals("BLANCO",s.getFirstBorder()); assertEquals("NEGRO",s.getSecondBorder());
        assertEquals("RANDOM",s.getMachine()); assertEquals(45.0,s.getRemainingTime(),0.001);
    }
    @Test public void saveStateAddCoinsAndElements() {
        SaveState s = new SaveState("L","PLAYER","BLINKY","INKY","B","N","RANDOM",60);
        s.addCollectedCoin("c1"); s.addUsedElement("e1"); s.addPlayerLine("1,40,40,40,40,0,1,0");
        assertEquals(1, s.getCollectedCoins().size());
        assertEquals(1, s.getUsedElements().size());
        assertEquals(1, s.getPlayerLines().size());
    }
    @Test public void textSaveStorageSaveAndLoad() throws Exception {
        File f = tmp.newFile("save.txt");
        SaveState original = new SaveState("TestLevel","PLAYER","BLINKY","INKY","BLANCO","NEGRO","RANDOM",55.0);
        original.addCollectedCoin("coin1"); original.addUsedElement("bomb1");
        original.addPlayerLine("1,40.0,40.0,40.0,40.0,0,1,0");
        TextSaveStorage storage = new TextSaveStorage();
        storage.save(f, original);
        SaveState loaded = storage.load(f);
        assertEquals("TestLevel", loaded.getLevelName());
        assertEquals(55.0, loaded.getRemainingTime(), 0.001);
        assertEquals(1, loaded.getCollectedCoins().size());
        assertEquals(1, loaded.getUsedElements().size());
        assertEquals(1, loaded.getPlayerLines().size());
    }
    @Test public void textErrorSinkWritesFile() throws Exception {
        File f = tmp.newFile("errors.txt");
        TextErrorSink sink = new TextErrorSink(f);
        sink.write(new RuntimeException("test error"));
        assertTrue(f.length() > 0);
    }

    // ═══════════════════════════════════════════════════════
    // APPLICATION — GameSetup, GameApplication + snapshot
    // ═══════════════════════════════════════════════════════

    @Test public void gameSetupGetters() {
        GameSetup s = new GameSetup("Lv1","PLAYER","BLINKY","INKY","BLANCO","NEGRO","RANDOM",true);
        assertEquals("Lv1",s.getLevelName()); assertEquals("PLAYER",s.getMode());
        assertEquals("BLINKY",s.getFirstSkin()); assertEquals("INKY",s.getSecondSkin());
        assertEquals("BLANCO",s.getFirstBorder()); assertEquals("NEGRO",s.getSecondBorder());
        assertEquals("RANDOM",s.getMachine()); assertTrue(s.hasMusic());
    }
    @Test public void gameApplicationSnapshotNoGame() {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        GameSnapshot snap = app.snapshot();
        assertEquals("Sin partida", snap.getLevelName());
        assertEquals(0, snap.getTotalCoins());
    }
    @Test public void gameApplicationModeNames() {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        List<String> modes = app.modeNames();
        assertTrue(modes.contains("PLAYER"));
        assertTrue(modes.contains("PLAYER_VS_PLAYER"));
        assertTrue(modes.contains("PLAYER_VS_MACHINE"));
    }
    @Test public void gameApplicationSkinNames() {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        assertFalse(app.skinNames().isEmpty());
    }
    @Test public void gameApplicationMachineNames() {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        assertFalse(app.machineNames().isEmpty());
    }
    @Test public void gameApplicationTickWithoutGame() throws Exception {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        app.tick(0.02); // Should not throw
    }
    @Test public void gameApplicationFinishWithoutGame() {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        app.finish(); // Should not throw
    }
    @Test public void gameApplicationPauseOrResumeWithoutGame() {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        app.pauseOrResume(); // Should not throw
    }
    @Test(expected=Exception.class) public void gameApplicationSaveWithoutGame() throws Exception {
        GameApplication app = new GameApplication(null, null, new SkinCatalog(), new MachineCatalog());
        app.save(tmp.newFile("save.txt"));
    }
    @Test public void gameApplicationSnapshotWithGame() throws Exception {
        // Build a stub LevelSource that returns our test level
        final Level level = baseLevel();
        level.addCoin(new YellowCoin("c1",40,40));
        level.addSpecialElement(new LifeSource("ls1",300,100));
        level.addEnemy(new LinearEnemy("e1",200,100,20,1,0,50));
        edu.dopo.application.LevelSource source = new edu.dopo.application.LevelSource() {
            public java.util.List<String> names() { return java.util.Arrays.asList("Test"); }
            public Level load(String name) { return level; }
        };
        TextSaveStorage storage = new TextSaveStorage();
        GameApplication app = new GameApplication(source, storage, new SkinCatalog(), new MachineCatalog());
        app.start(new GameSetup("Test","PLAYER","BLINKY","INKY","BLANCO","NEGRO","RANDOM",false));
        app.setDirection(1,1,0);
        app.tick(0.02);
        app.pauseOrResume(); // pauses
        app.pauseOrResume(); // resumes
        GameSnapshot snap = app.snapshot();
        assertTrue(snap.getWidth() > 0);
        assertFalse(snap.getRenderItems().isEmpty());
        assertFalse(snap.getPlayerStatus().isEmpty());
    }
    @Test public void gameApplicationSaveAndOpen() throws Exception {
        final Level level = baseLevel();
        level.addCoin(new YellowCoin("c1",40,40));
        edu.dopo.application.LevelSource source = new edu.dopo.application.LevelSource() {
            public java.util.List<String> names() { return java.util.Arrays.asList("Test"); }
            public Level load(String name) {
                Level l = baseLevel(); l.addCoin(new YellowCoin("c1",40,40)); return l;
            }
        };
        TextSaveStorage storage = new TextSaveStorage();
        GameApplication app = new GameApplication(source, storage, new SkinCatalog(), new MachineCatalog());
        app.start(new GameSetup("Test","PLAYER","BLINKY","INKY","BLANCO","NEGRO","RANDOM",false));
        app.tick(0.02);
        File f = tmp.newFile("game.txt");
        app.save(f);
        app.open(f);
        assertNotNull(app.snapshot());
    }

    // ═══════════════════════════════════════════════════════
    // PRESENTATION — ColorPalette
    // ═══════════════════════════════════════════════════════

    @Test public void colorPaletteKnownColors() {
        ColorPalette p = new ColorPalette();
        assertNotNull(p.get("BLANCO"));
        assertNotNull(p.get("NEGRO"));
        assertNotNull(p.get("ROJO"));
        assertNotNull(p.get("AZUL"));
        assertNotNull(p.get("VERDE"));
        assertNotNull(p.get("MORADO"));
        assertNotNull(p.get("NARANJA"));
    }
    @Test public void colorPaletteFallbackToWhite() {
        ColorPalette p = new ColorPalette();
        assertNotNull(p.get("COLOR_INEXISTENTE")); // returns white
    }
    @Test public void colorPaletteNames() {
        ColorPalette p = new ColorPalette();
        String[] names = p.names();
        assertTrue(names.length >= 7);
    }
    
 // ═══════════════════════════════════════════════════════
 // COLLISION SERVICE
 // ═══════════════════════════════════════════════════════

 @Test public void collisionServiceIntersectsActive() {
     CollisionService cs = new CollisionService();
     YellowCoin a = new YellowCoin("a", 10, 10);
     YellowCoin b = new YellowCoin("b", 15, 15);
     assertTrue(cs.intersects(a, b));
 }
 @Test public void collisionServiceIntersectsInactive() {
     CollisionService cs = new CollisionService();
     YellowCoin a = new YellowCoin("a", 10, 10);
     YellowCoin b = new YellowCoin("b", 15, 15);
     a.deactivate();
     assertFalse(cs.intersects(a, b));
 }
 @Test public void collisionServiceNoIntersect() {
     CollisionService cs = new CollisionService();
     YellowCoin a = new YellowCoin("a", 0, 0);
     YellowCoin b = new YellowCoin("b", 200, 200);
     assertFalse(cs.intersects(a, b));
 }
 @Test public void collisionServiceCanOccupy() {
     CollisionService cs = new CollisionService();
     Level l = new Level("L", 400, 300, 60);
     assertTrue(cs.canOccupy(l, new Rect(100, 100, 20, 20)));
 }
 @Test public void collisionServiceCannotOccupyOutside() {
     CollisionService cs = new CollisionService();
     Level l = new Level("L", 100, 100, 60);
     assertFalse(cs.canOccupy(l, new Rect(95, 95, 20, 20)));
 }
 @Test public void collisionServiceCannotOccupyWall() {
     CollisionService cs = new CollisionService();
     Level l = new Level("L", 400, 300, 60);
     l.addWall(new Wall("w1", 100, 100, 50, 50));
     assertFalse(cs.canOccupy(l, new Rect(110, 110, 20, 20)));
 }
 @Test public void collisionServicePlayersCollide() throws Exception {
     CollisionService cs = new CollisionService();
     Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
     // put two players at same position — use player bounds directly
     Game g2 = makeGame2P(baseLevelTwoPlayers(), GameModes.PLAYER_VS_PLAYER);
     g2.player(2).setPosition(g2.player(1).getX(), g2.player(1).getY());
     assertTrue(cs.playersCollide(g2.player(1), g2.player(2)));
 }

 // ═══════════════════════════════════════════════════════
 // TEXT LEVEL SOURCE
 // ═══════════════════════════════════════════════════════

 @Test public void textLevelSourceNamesAndLoad() throws Exception {
     File dir = tmp.newFolder("levels");
     File lvl = new File(dir, "level1.txt");
     java.io.PrintWriter pw = new java.io.PrintWriter(lvl);
     pw.println("name=TestLevel");
     pw.println("width=420");
     pw.println("height=180");
     pw.println("time=60");
     pw.println("zone=START,1,40,40,60,60");
     pw.println("zone=END,1,360,40,50,60");
     pw.println("wall=w1,0,0,420,10");
     pw.println("coin=yellow,c1,100,80");
     pw.close();
     edu.dopo.persistence.TextLevelSource src =
         new edu.dopo.persistence.TextLevelSource(dir, new SkinCatalog());
     java.util.List<String> names = src.names();
     assertEquals(1, names.size());
     assertEquals("TestLevel", names.get(0));
     edu.dopo.domain.model.Level loaded = src.load("TestLevel");
     assertEquals("TestLevel", loaded.getName());
     assertEquals(420, loaded.getWidth());
     assertEquals(1, loaded.totalCoins());
 }
 @Test(expected = Exception.class) public void textLevelSourceLoadUnknown() throws Exception {
     File dir = tmp.newFolder("levels2");
     edu.dopo.persistence.TextLevelSource src =
         new edu.dopo.persistence.TextLevelSource(dir, new SkinCatalog());
     src.load("NoExiste");
 }
 @Test public void textLevelSourceWithEnemy() throws Exception {
     File dir = tmp.newFolder("levels3");
     File lvl = new File(dir, "level.txt");
     java.io.PrintWriter pw = new java.io.PrintWriter(lvl);
     pw.println("name=EnemyLevel");
     pw.println("width=420");
     pw.println("height=180");
     pw.println("time=60");
     pw.println("zone=START,1,40,40,60,60");
     pw.println("zone=END,1,360,40,50,60");
     pw.println("wall=w1,0,0,420,10");
     pw.println("enemy=linear,e1,100,100,20,1,0,100");
     pw.println("enemy=fast,e2,200,100,20,1,0,100");
     pw.println("enemy=vertical,e3,300,100,20,100");
     pw.println("enemy=patrol,e4,150,100,20,100,50:50|200:100");
     pw.println("special=life,s1,100,80");
     pw.println("special=bomb,b1,200,80");
     pw.println("coin=skin,sc1,80,80,BLINKY");
     pw.close();
     edu.dopo.persistence.TextLevelSource src =
         new edu.dopo.persistence.TextLevelSource(dir, new SkinCatalog());
     edu.dopo.domain.model.Level loaded = src.load("EnemyLevel");
     assertEquals(4, loaded.getEnemies().size());
 }

 // ═══════════════════════════════════════════════════════
 // SKINS
 // ═══════════════════════════════════════════════════════

 @Test public void blinkySkinProperties() {
     edu.dopo.domain.skin.BlinkySkin s = new edu.dopo.domain.skin.BlinkySkin();
     assertEquals("BLINKY", s.key());
     assertNotNull(s.name());
     assertEquals(1.0, s.speedFactor(), 0.001);
     assertEquals(1.0, s.sizeFactor(), 0.001);
     assertFalse(s.absorbsFirstHit());
     assertEquals(1.0, s.weakenedSpeedFactor(), 0.001);
     assertEquals("PLAYER_BLINKY", s.renderKey());
 }
 @Test public void clydeSkinProperties() {
     edu.dopo.domain.skin.ClydeSkin s = new edu.dopo.domain.skin.ClydeSkin();
     assertEquals("CLYDE", s.key());
     assertNotNull(s.name());
     assertEquals(1.0, s.speedFactor(), 0.001);
     assertEquals(1.0, s.sizeFactor(), 0.001);
     assertTrue(s.absorbsFirstHit());
     assertEquals(0.7, s.weakenedSpeedFactor(), 0.001);
     assertEquals("PLAYER_CLYDE", s.renderKey());
 }
 @Test public void inkySkinProperties() {
     edu.dopo.domain.skin.InkySkin s = new edu.dopo.domain.skin.InkySkin();
     assertEquals("INKY", s.key());
     assertNotNull(s.name());
     assertEquals(1.5, s.speedFactor(), 0.001);
     assertEquals(1.5, s.sizeFactor(), 0.001);
     assertFalse(s.absorbsFirstHit());
     assertEquals(1.5, s.weakenedSpeedFactor(), 0.001);
     assertEquals("PLAYER_INKY", s.renderKey());
 }

 // ═══════════════════════════════════════════════════════
 // GAME OBJECT (via Wall / YellowCoin)
 // ═══════════════════════════════════════════════════════

 @Test public void gameObjectGetters() {
     Wall w = new Wall("wall1", 10, 20, 50, 30);
     assertEquals("wall1", w.getId());
     assertEquals(10.0, w.getX(), 0.001);
     assertEquals(20.0, w.getY(), 0.001);
     assertEquals(50.0, w.getWidth(), 0.001);
     assertEquals(30.0, w.getHeight(), 0.001);
     assertEquals("WALL", w.renderKey());
 }
 @Test public void gameObjectActivateDeactivate() {
     Wall w = new Wall("w", 0, 0, 10, 10);
     assertTrue(w.isActive());
     w.deactivate();
     assertFalse(w.isActive());
     w.activate();
     assertTrue(w.isActive());
 }
 @Test public void gameObjectGetPosition() {
     Wall w = new Wall("w", 5, 7, 10, 10);
     assertEquals(5.0, w.getPosition().getX(), 0.001);
     assertEquals(7.0, w.getPosition().getY(), 0.001);
 }
 @Test public void yellowCoinRenderKey() {
     assertEquals("COIN_YELLOW", new YellowCoin("c", 0, 0).renderKey());
 }
 @Test public void coinCollectTwiceOnlyOnce() throws Exception {
     YellowCoin coin = new YellowCoin("c1", 40, 40);
     Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
     coin.collect(g.player(1));
     coin.collect(g.player(1)); // segunda vez — no debe contar
     assertEquals(1, g.player(1).getCollectedCoins());
 }
 @Test public void gameExceptionMessage() {
     GameException e = new GameException("error test");
     assertEquals("error test", e.getMessage());
 }
 @Test public void gameExceptionWithCause() {
     RuntimeException cause = new RuntimeException("causa");
     GameException e = new GameException("error", cause);
     assertEquals(cause, e.getCause());
 }

 // ═══════════════════════════════════════════════════════
 // PLAYER — métodos no cubiertos
 // ═══════════════════════════════════════════════════════

 @Test public void playerSpeedNormal() throws Exception {
     Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
     assertTrue(g.player(1).speed() > 0);
 }
 @Test public void playerSpeedWeakened() throws Exception {
     Game g = makeGame(baseLevel(), GameModes.PLAYER, "CLYDE");
     g.player(1).hitByEnemy(); // weakens Clyde
     assertTrue(g.player(1).isWeakened());
     double weakSpeed = g.player(1).speed();
     assertTrue(weakSpeed > 0 && weakSpeed < 180);
 }
 @Test public void playerChangeSkinAndRecover() throws Exception {
     Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
     g.player(1).changeSkin(new SkinCatalog().create("CLYDE"));
     assertEquals("CLYDE", g.player(1).getSkinKey());
     g.player(1).recoverOriginalSkin();
     assertEquals("BLINKY", g.player(1).getSkinKey());
 }
 @Test public void playerSetCheckpoint() throws Exception {
     Game g = makeGame(baseLevel(), GameModes.PLAYER, "BLINKY");
     g.player(1).setCheckpoint(200, 100);
     assertEquals(200.0, g.player(1).getSpawn().getX(), 0.001);
 }
 @Test public void playerInkyIsLarger() throws Exception {
     Game g = makeGame(baseLevel(), GameModes.PLAYER, "INKY");
     assertTrue(g.player(1).getWidth() > 24.0); // sizeFactor 1.5
 }

 // ═══════════════════════════════════════════════════════
 // GAME APPLICATION — levelNames
 // ═══════════════════════════════════════════════════════

 @Test public void gameApplicationLevelNames() throws Exception {
     File dir = tmp.newFolder("lvlsrc");
     File lvl = new File(dir, "level1.txt");
     java.io.PrintWriter pw = new java.io.PrintWriter(lvl);
     pw.println("name=Nivel1");
     pw.println("width=420"); pw.println("height=180"); pw.println("time=60");
     pw.println("zone=START,1,40,40,60,60");
     pw.println("zone=END,1,360,40,50,60");
     pw.println("wall=w1,0,0,420,10");
     pw.close();
     edu.dopo.persistence.TextLevelSource src =
         new edu.dopo.persistence.TextLevelSource(dir, new SkinCatalog());
     GameApplication app = new GameApplication(src, new TextSaveStorage(), new SkinCatalog(), new MachineCatalog());
     assertTrue(app.levelNames().contains("Nivel1"));
 }
    

    // ═══════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════

    private Game makeGame(Level level, String mode, String skin) throws Exception {
        return new Game(level, mode, new SkinCatalog().create(skin),
                new SkinCatalog().create("INKY"), "BLANCO", "NEGRO", null);
    }
    private Game makeGame2P(Level level, String mode) throws Exception {
        return new Game(level, mode, new SkinCatalog().create("BLINKY"),
                new SkinCatalog().create("INKY"), "BLANCO", "NEGRO", null);
    }
    private Level baseLevel() {
        Level l = new Level("Test",420,180,60);
        l.addZone(new Zone("s1",ZoneKinds.START, 1, 40, 40,60,60));
        l.addZone(new Zone("e1",ZoneKinds.END,   1,360, 40,50,60));
        l.addZone(new Zone("s2",ZoneKinds.START, 2,360, 40,50,60));
        l.addZone(new Zone("e2",ZoneKinds.END,   2, 40, 40,60,60));
        l.addWall(new Wall("w1",0,0,420,10));
        return l;
    }
    private Level baseLevelTwoPlayers() {
        Level l = new Level("Test2P",420,180,60);
        l.addZone(new Zone("s1",ZoneKinds.START, 1, 40, 40,60,60));
        l.addZone(new Zone("e1",ZoneKinds.END,   1,360, 40,50,60));
        l.addZone(new Zone("s2",ZoneKinds.START, 2,200,100,50,50));
        l.addZone(new Zone("e2",ZoneKinds.END,   2, 40, 40,60,60));
        l.addWall(new Wall("w1",0,0,420,10));
        return l;
    }
    private Level enemyLevel() {
        Level l = new Level("E",400,300,60);
        l.addWall(new Wall("w1",0,0,400,5));
        return l;
    }
}